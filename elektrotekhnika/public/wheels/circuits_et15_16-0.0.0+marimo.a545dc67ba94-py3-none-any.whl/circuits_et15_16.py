"""Shared drawing + cross-check helpers for ЕТ15, ЕТ16 (marimo notebooks).

ЕТ15 and ЕТ16 solve two halves of the same worked example: a branch R₃
carrying a current known only through its own power (ЕТ15's "задача
навпаки") feeds a two-way current divider (R₄ ‖ R₅); that combined branch
then sits in series with R₆ and in parallel with R₁ across an ideal
source E (ЕТ16, finishing the problem: U_AB, R_eq, I₁, the branch-current
sum, and E itself). Factored here so ЕТ16 can reuse ЕТ15's divider
geometry and solver rather than redraw/re-derive it, matching the
shared-helper convention `circuits_et04_06.py` / `circuits_et09_10.py` /
`circuits_et13_14.py` already established for this course.

Every cross-check here is a sympy `linear_eq_to_matrix` solve of the same
underlying rules the note derives its shortcut formulas from -- equal
voltage across parallel branches (ЕТ05) and the first Kirchhoff law
(ЕТ09) for the divider; the parallel-resistance formula (ЕТ13) and Ohm's
law for ЕТ16's forward re-derivation -- never a restatement of the
step-by-step formula as its own "proof". Every value passed into
`sp.Rational` goes through `str(x)` first (not a bare float) so sympy
parses the decimal string exactly instead of the binary float noise
behind it -- see `circuits_et13_14.py`'s docstring for why this matters
once sliders carry non-integer defaults.

lcapy is NOT imported anywhere in this module and never will be (see
`_notebooks/verify_et13.py`'s docstring for why).
"""
import schemdraw
import schemdraw.elements as elm
import sympy as sp

schemdraw.use("matplotlib")


def draw_current_divider(R3, R4, R5, I3, I4, I5):
    """ЕТ15: R3 in series feeding a current divider (R4 ‖ R5)."""
    d = schemdraw.Drawing()
    d += elm.Arrow().right().length(1.3).label(f"I₃ = {I3:.3g} А", loc="top")
    d += elm.Resistor().right().label(f"R₃ = {R3:g} Ом")

    d.push()
    d += elm.Line().up().length(1.3)
    d += (_r4 := elm.Resistor().right().label(f"R₄ = {R4:g} Ом\nI₄ = {I4:.3g} А"))
    d.pop()

    d += elm.Line().down().length(1.3)
    d += (_r5 := elm.Resistor().right().label(f"R₅ = {R5:g} Ом\nI₅ = {I5:.3g} А"))

    d += elm.Line().at(_r4.end).right().tox(_r5.end)
    d += elm.Line().down().toy(_r5.end)
    d += elm.Arrow().right().length(1.3).label(f"I₃ = {I3:.3g} А", loc="top")
    return d.draw(show=False)


def solve_divider_matrix(I3, R4, R5):
    """Current divider as a 2-equation system: equal voltage (ЕТ05) + first law (ЕТ09).

    Not the shortcut formula I4 = I3*R5/(R4+R5) restated -- the two rules
    that formula is DERIVED from, solved independently via
    `sp.linear_eq_to_matrix`.
    """
    I3s, R4s, R5s = (sp.Rational(str(x)) for x in (I3, R4, R5))
    I4, I5 = sp.symbols("I4 I5")
    eqs = [
        sp.Eq(I4 * R4s, I5 * R5s),  # та сама напруга на обох гілках (ЕТ05)
        sp.Eq(I4 + I5, I3s),  # перший закон Кірхгофа (ЕТ09)
    ]
    A, b = sp.linear_eq_to_matrix(eqs, [I4, I5])
    I4v, I5v = A.solve(b)
    return {"I4": float(I4v), "I5": float(I5v)}, A, b


def draw_two_branches(E, R1, R3, R_cd, R6, I1, I3):
    """ЕТ16: R1 alone in parallel with the R3+R_цд+R6 chain, across source E.

    Same shared-branch-pair geometry as `circuits_et04_06.draw_mixed`
    (push/pop for the short branch, then the longer branch, then closing
    lines) generalized to a 3-resistor long branch instead of 1.
    """
    d = schemdraw.Drawing()
    d += elm.SourceV().up().label(f"E = {E:g} В")

    d.push()
    d += elm.Line().up().length(1.5)
    d += (_r1 := elm.Resistor().right().label(f"R₁={R1:g} Ом\nI₁={I1:.3g} А"))
    d.pop()

    d += elm.Line().down().length(1.5)
    d += elm.Resistor().right().label(f"R₃={R3:g} Ом")
    d += elm.Resistor().right().label(f"R_цд={R_cd:.3g} Ом")
    d += (_r6 := elm.Resistor().right().label(f"R₆={R6:g} Ом\nI₃={I3:.3g} А"))

    d += elm.Line().at(_r1.end).right().tox(_r6.end)
    d += elm.Line().down().toy(_r6.end)

    d += elm.Line().right()
    d += elm.Line().down()
    d += elm.Line().left().tox(0)
    d += elm.Line().up().toy(0)
    return d.draw(show=False)


def solve_full_matrix(I3, R3, R_cd, R6, R1):
    """ЕТ16 cross-check: same two-parallel-branch circuit, solved forward.

    The note's own path goes BACKWARD -- known branch current I3 gives
    U_AB, U_AB gives I1, I1+I3 gives the total, and total*R_eq gives E.
    This re-derives I1 via a one-equation system, "I1*R1 = U_AB" (equal
    voltage across parallel branches, ЕТ05) solved with
    `sp.linear_eq_to_matrix` -- an independent statement of the same
    physical rule, not the same arithmetic run twice -- then recombines
    with the first Kirchhoff law (ЕТ09) and the parallel-resistance
    formula (ЕТ13) to reproduce I_total, R_eq and E.
    """
    I3s, R3s, R_cds, R6s, R1s = (sp.Rational(str(x)) for x in (I3, R3, R_cd, R6, R1))
    R_branch = R3s + R_cds + R6s
    U_AB = I3s * R_branch

    I1 = sp.symbols("I1")
    eq = sp.Eq(I1 * R1s, U_AB)  # та сама напруга на обох гілках (ЕТ05)
    A, b = sp.linear_eq_to_matrix([eq], [I1])
    (I1v,) = A.solve(b)

    I_total = I1v + I3s  # перший закон Кірхгофа (ЕТ09)
    R_eq = (R1s * R_branch) / (R1s + R_branch)  # паралельна пара (ЕТ13)
    E = I_total * R_eq

    return {
        "U_AB": float(U_AB),
        "I1": float(I1v),
        "I_total": float(I_total),
        "R_eq": float(R_eq),
        "E": float(E),
    }, A, b
