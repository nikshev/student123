"""Shared drawing + cross-check helpers for ЕТ04, ЕТ05, ЕТ06 (marimo notebooks).

ЕТ04's circuit and ЕТ05/ЕТ06's circuit are the same family: a source, R1 in
series, and then either two more series resistors (ЕТ04) or a parallel
pair off the same two nodes (ЕТ05, ЕТ06 -- identical circuit, ЕТ06 reuses
ЕТ05's numbers to talk about power instead of current). Factoring the
drawing geometry and the independent-method cross-check here keeps the
three notebooks from silently drifting on those two pieces, while the
per-episode narrated step-by-step (handcalcs cells, prose) stays local to
each notebook -- that's the part that's genuinely different lesson to
lesson and shouldn't be abstracted away.

marimo's `export html-wasm` auto-packages a local sibling import like this
one into a content-addressed wheel and installs it via micropip alongside
the notebook's own PyPI deps -- confirmed empirically before relying on
it: a minimal test notebook importing a local module exported cleanly,
served, and loaded in a real browser via CDP with
`Loading from micropip: [..., 'circuits_et04_06 @ ../public/wheels/...']`
and no ModuleNotFoundError, then recomputed correctly after a live slider
move. So this import is safe for the browser runtime, unlike lcapy (see
`_notebooks/verify_et13.py`'s docstring for why lcapy specifically is
never allowed here) -- lcapy is not imported anywhere in this module.

The cross-check functions solve the same circuits via node-voltage
Kirchhoff equations (`sp.linear_eq_to_matrix` + `.solve`), independent of
the step-by-step collapse each notebook narrates -- the same method
ЕТ09/ЕТ10 teach and the same approach `et13.py`'s pilot established.
"""
import schemdraw
import schemdraw.elements as elm
import sympy as sp

schemdraw.use("matplotlib")


def draw_series3(E, R1, R2, R3):
    """ЕТ04: source + three resistors, one straight series loop."""
    d = schemdraw.Drawing()
    d += elm.SourceV().up().label(f"E = {E:g} В")
    d += elm.Resistor().right().label(f"R₁ = {R1:g} Ом")
    d += elm.Resistor().right().label(f"R₂ = {R2:g} Ом")
    d += elm.Resistor().right().label(f"R₃ = {R3:g} Ом")
    d += elm.Line().down()
    d += elm.Line().left().tox(0)
    d += elm.Line().up().toy(0)
    return d.draw(show=False)


def draw_mixed(E, R1, R2, R3):
    """ЕТ05/ЕТ06: R1 in series, then R2 ‖ R3 off the same two nodes."""
    d = schemdraw.Drawing()
    d += elm.SourceV().up().label(f"E = {E:g} В")
    d += (_r1 := elm.Resistor().right().label(f"R₁ = {R1:g} Ом"))

    d.push()
    d += elm.Line().up().length(1.5)
    d += (_r2 := elm.Resistor().right().label(f"R₂ = {R2:g} Ом"))
    d.pop()

    d += elm.Line().down().length(1.5)
    d += (_r3 := elm.Resistor().right().label(f"R₃ = {R3:g} Ом"))

    d += elm.Line().at(_r2.end).right().tox(_r3.end)
    d += elm.Line().down().toy(_r3.end)

    d += elm.Line().right()
    d += elm.Line().down()
    d += elm.Line().left().tox(0)
    d += elm.Line().up().toy(0)
    return d.draw(show=False)


def solve_series3_matrix(E, R1, R2, R3):
    """ЕТ04 cross-check: node-voltage KVL for the two internal nodes.

    Node A sits between R1 and R2; node B sits between R2 and R3. Current
    into a node equals current out (ЕТ09), each branch current is a
    voltage difference over that branch's resistance (ЕТ10/Ohm's law).
    Returns (values, A, b) so the caller can render the matrix too.
    """
    E, R1, R2, R3 = (sp.Rational(x) for x in (E, R1, R2, R3))
    Va, Vb = sp.symbols("Va Vb")
    eqs = [
        sp.Eq((E - Va) / R1, (Va - Vb) / R2),  # вузол A
        sp.Eq((Va - Vb) / R2, Vb / R3),  # вузол B
    ]
    A, b = sp.linear_eq_to_matrix(eqs, [Va, Vb])
    Va_v, Vb_v = A.solve(b)
    I = (E - Va_v) / R1
    R_eq = E / I
    return {"I": float(I), "R_eq": float(R_eq)}, A, b


def solve_mixed(U, R1, R2, R3):
    """ЕТ05/ЕТ06 numbers via the step-by-step method, as exact fractions.

    Used both to power ЕТ05's own narrated steps and, unchanged, to give
    ЕТ06 the circuit numbers (I, U1, U23) it needs before it moves on to
    power -- exactly like the ЕТ06 note itself, which recaps ЕТ05's
    numbers rather than re-deriving them.
    """
    U, R1, R2, R3 = (sp.Rational(x) for x in (U, R1, R2, R3))
    R23 = (R2 * R3) / (R2 + R3)
    R_total = R1 + R23
    I = U / R_total
    U1 = I * R1
    U23 = I * R23
    I2 = U23 / R2
    I3 = U23 / R3
    return {
        "R23": float(R23), "R_total": float(R_total), "I": float(I),
        "U1": float(U1), "U23": float(U23), "I2": float(I2), "I3": float(I3),
    }


def solve_mixed_matrix(E, R1, R2, R3):
    """ЕТ05/ЕТ06 cross-check: node-voltage KVL for the one internal node.

    Node A sits between R1 and the R2‖R3 pair (both share the same two
    nodes, A and ground). Same method as `solve_series3_matrix`, one
    unknown instead of two because there's one fewer real node here.
    """
    E, R1, R2, R3 = (sp.Rational(x) for x in (E, R1, R2, R3))
    Va = sp.symbols("Va")
    eqs = [sp.Eq((E - Va) / R1, Va / R2 + Va / R3)]  # вузол A
    A, b = sp.linear_eq_to_matrix(eqs, [Va])
    (Va_v,) = A.solve(b)
    I = (E - Va_v) / R1
    I2 = Va_v / R2
    I3 = Va_v / R3
    R_eq = E / I
    return {"I": float(I), "I2": float(I2), "I3": float(I3), "R_eq": float(R_eq)}, A, b
