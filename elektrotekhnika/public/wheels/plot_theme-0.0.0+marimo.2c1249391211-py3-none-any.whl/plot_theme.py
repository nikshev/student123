"""Дві теми для однієї сторінки: світла й темна графіка поруч.

Чому не «одна картинка під поточну тему». Ядро marimo у WASM виконується
у **Web Worker**, де немає ні `window`, ні `matchMedia`, тож Python не
може дізнатися, що бачить глядач; `mo.app_meta().theme` при
`theme = "system"` повертає рядок КОНФІГУ — буквально "system".
Перевірено на ЕТ13: сторінка темніла правильно, а схема лишалась
намальованою чорним по прозорому.

Тому малюємо ДВІЧІ й віддаємо вибір браузеру: `<picture>` з
`media="(prefers-color-scheme: dark)"` — чистий HTML, без CSS-блоку і без
JS. Python про тему не питає взагалі.

Ціна: кожна фігура рендериться двічі. Схеми тут маленькі, і це дешевше за
будь-який спосіб дотягнутись із воркера до теми сторінки.

Використання:

    # замість  _fig = draw_network5(E, R1, …)
    _fig = plot_theme.dual(draw_network5, E, R1, …)

    # або для коду, що будує фігуру на місці
    def _make():
        ...
        return fig
    _fig = plot_theme.dual(_make)

Усередині `fn` кольори беруться з `plot_theme.palette()` або
`plot_theme.apply()`; `dual()` підміняє тему перед кожним викликом.

Поза браузером (`verify_*.py` — звичайний Python) `palette()` віддає
світлу, тобто стару поведінку.
"""
import base64
import io

LIGHT = {
    "ink": "#1b1b1f",      # підписи, заголовок, штрихи схеми
    "muted": "#5b5b66",    # цифри на осях
    "grid": "#e2e2e8",     # сітка й осі
    "box": "#ffffff",      # плашка під підписом усередині фігури
    "accent": "#2a78d6",   # лінія графіка
}
DARK = {
    "ink": "#e8e8ee",
    "muted": "#a9a9b6",
    "grid": "#3c3c47",
    "box": "#1b1b1f",
    "accent": "#5aa0ff",
}

_force = None


def _configured() -> str:
    try:
        import marimo as mo

        return mo.app_meta().theme or "light"
    except Exception:
        return "light"


def theme() -> str:
    """Тема, у якій малюємо ЗАРАЗ. Під час `dual()` — примусова."""
    if _force:
        return _force
    configured = _configured()
    return configured if configured in ("light", "dark") else "light"


def palette() -> dict:
    return DARK if theme() == "dark" else LIGHT


def ink() -> str:
    """Колір штрихів схеми. Типовий колір schemdraw — літерально "black",
    через що на темній темі схема ставала чорним прямокутником на чорному."""
    return palette()["ink"]


def apply() -> str:
    """Прозоре тло фігури + підписи кольором теми. Повертає ink()."""
    p = palette()
    try:
        import matplotlib as mpl

        mpl.rcParams.update({
            "figure.facecolor": "none",
            "axes.facecolor": "none",
            "savefig.facecolor": "none",
            "savefig.transparent": True,
            "text.color": p["ink"],
            "axes.labelcolor": p["ink"],
            "axes.edgecolor": p["grid"],
            "xtick.color": p["muted"],
            "ytick.color": p["muted"],
            "grid.color": p["grid"],
        })
    except Exception:
        pass
    return p["ink"]


def _data_uri(obj) -> str:
    """SVG фігури як data-URI. `obj` — matplotlib Figure або результат
    `schemdraw.Drawing.draw()` (у нього сама фігура лежить в `.fig`)."""
    fig = getattr(obj, "fig", obj)
    buf = io.BytesIO()
    fig.savefig(buf, format="svg", transparent=True, bbox_inches="tight")
    try:
        import matplotlib.pyplot as plt

        plt.close(fig)
    except Exception:
        pass
    return ("data:image/svg+xml;base64,"
            + base64.b64encode(buf.getvalue()).decode("ascii"))


def dual(fn, *args, **kwargs):
    """Намалювати `fn` двічі — світлою й темною — і віддати `<picture>`,
    де браузер сам бере потрібну за `prefers-color-scheme`."""
    global _force
    src = {}
    for mode in ("light", "dark"):
        _force = mode
        try:
            src[mode] = _data_uri(fn(*args, **kwargs))
        finally:
            _force = None

    html = (
        "<picture>"
        f'<source media="(prefers-color-scheme: dark)" srcset="{src["dark"]}">'
        f'<img src="{src["light"]}" alt="" '
        'style="width:100%;height:auto;display:block">'
        "</picture>"
    )
    try:
        import marimo as mo
    except ImportError:
        # Поза marimo (verify_*.py) віддаємо сиру розмітку, а не падаємо.
        return html
    return mo.Html(html)
