"""Shared drawing + cross-check helpers for ЕТ09, ЕТ10 (marimo notebooks).

ЕТ09 (first law: node) and ЕТ10 (second law: loop) are the two episodes
where the sympy matrix method is the SUBJECT, not a cross-check of some
other derivation (contrast `circuits_et04_06.py`, where the matrix solve
is an independent-method check on a series/mixed circuit already solved
by hand above it). So the functions here build the same kind of A, b
matrix circuits_et04_06 builds, but the notebooks present them as "this
row/equation IS the law", not "here's a second way to get the same
answer" -- see et09.py's and et10.py's "## Закон як матриця" cells.

marimo's `export html-wasm` auto-packages a local sibling import like this
one into a content-addressed wheel installed via micropip, landing at
`public/wheels/` as a *sibling* of the exported page's `assets/` dir --
confirmed for `circuits_et04_06.py` (see that module's docstring) and
re-verified here after adding this second shared module (see
`.superpowers/sdd/2026-09-17-tanos-electrotech-course/marimo-et07-09-10.md`).
lcapy is NOT imported anywhere in this module and never will be (see
`_notebooks/verify_et13.py`'s docstring for why).
"""
import schemdraw
import schemdraw.elements as elm
import sympy as sp

schemdraw.use("matplotlib")


def draw_node_signflip(I_in, I_out_known, I_unknown):
    """ЕТ09 sign-flip node: one current in, two branches DRAWN as 'out'.

    Both right-hand arrows point away from the node -- that's the
    direction the student (or the note) guessed before doing any
    algebra, and it never changes. Only the unknown branch's own label
    carries whatever signed number the equation actually returns: a
    negative value here is the whole lesson (ЕТ09: "мінус — це не
    помилка, а відповідь"), so the arrow must NOT flip itself to hide it.
    """
    d = schemdraw.Drawing()
    d += elm.Dot().at((0, 0))
    d += elm.Arrow().at((-3, 0)).to((0, 0)).label(f"{I_in:g} А", loc="top")
    d += elm.Arrow().at((0, 0)).to((2.3, 1.6)).label(f"I? = {I_unknown:+.2f} А", loc="top")
    d += elm.Arrow().at((0, 0)).to((2.3, -1.6)).label(f"{I_out_known:g} А", loc="bottom")
    return d.draw(show=False)


def draw_node_household(I_in, I_charger, I_heater, I_lamp):
    """ЕТ09 household node: подовжувач, один вхід, три навантаження."""
    d = schemdraw.Drawing()
    d += elm.Dot().at((0, 0))
    d += elm.Arrow().at((-3, 0)).to((0, 0)).label(f"{I_in:g} А (від щитка)", loc="top")
    d += elm.Arrow().at((0, 0)).to((2.8, 1.8)).label(f"{I_charger:g} А (зарядка)", loc="top")
    d += elm.Arrow().at((0, 0)).to((3.2, 0)).label(f"{I_heater:g} А (обігрівач)", loc="top")
    d += elm.Arrow().at((0, 0)).to((2.8, -1.8)).label(f"{I_lamp:g} А (LED)", loc="bottom")
    return d.draw(show=False)


def solve_node_signflip(I_in, I_out_known):
    """First law as a 1-equation system for the sign-flip node.

    Convention (ЕТ09): entering '+', assumed-leaving '-'. I_unknown is
    also assumed leaving, so the node equation is
    I_in - I_out_known - I_x = 0. Returns (I_x, A, b) from
    `sp.linear_eq_to_matrix` so the caller can render the matrix, same
    as every `solve_*_matrix` in `circuits_et04_06.py`.
    """
    I_in_s, I_out_s = sp.Rational(I_in), sp.Rational(I_out_known)
    I_x = sp.symbols("I_x")
    eq = sp.Eq(I_in_s - I_out_s - I_x, 0)
    A, b = sp.linear_eq_to_matrix([eq], [I_x])
    (I_x_v,) = A.solve(b)
    return float(I_x_v), A, b


def solve_node_household(I_in, I_charger, I_heater, I_lamp):
    """First law as A @ I_vec for the 4-branch household node.

    A single row of signs (+1 entering, -1 leaving) times the branch
    current vector -- this row literally IS ΣI=0, just written as a
    matrix product instead of a sum with +/- in front of each term.
    `residual == 0` means the node balances; a nonzero residual is
    exactly what "breaking" the node with mismatched sliders looks like
    algebraically, not just visually.
    """
    signs = sp.Matrix([[1, -1, -1, -1]])
    I_vec = sp.Matrix([[sp.Rational(x)] for x in (I_in, I_charger, I_heater, I_lamp)])
    residual = (signs * I_vec)[0]
    return float(residual), signs, I_vec


def draw_loop2(E1, E2, R1, R2, R3, E2_reversed):
    """ЕТ10 loop: two EMFs in series with up to three resistors, closed.

    Same drawing family as `circuits_et04_06.draw_series3` (a source
    edge + a resistor edge + three closing lines back to the start),
    extended to two sources. When `E2_reversed` is True, E2 is drawn
    `.down()` instead of `.up()` -- a physical flip, matching the note's
    "battery inserted backwards" bit, not just a sign typed into the
    equation. `R3` is only drawn when > 0 (ЕТ10's `stop_check` step adds
    it to an otherwise two-resistor loop). A `LoopArrow` marks the
    traversal direction chosen for KVL -- arbitrary per the note, fixed
    to clockwise here so the drawing doesn't jitter between reruns.
    """
    d = schemdraw.Drawing()
    d += elm.SourceV().up().label(f"E₁ = {E1:g} В")
    if E2_reversed:
        d += elm.SourceV().down().label(f"E₂ = {E2:g} В\n(задом наперед)")
    else:
        d += elm.SourceV().up().label(f"E₂ = {E2:g} В")
    d += elm.Resistor().right().label(f"R₁ = {R1:g} Ом")
    d += elm.Resistor().right().label(f"R₂ = {R2:g} Ом")
    if R3 > 0:
        d += elm.Resistor().right().label(f"R₃ = {R3:g} Ом")
    d += elm.Line().down()
    d += elm.Line().left().tox(0)
    d += elm.Line().up().toy(0)
    d += elm.LoopArrow(direction="cw", width=1.4, height=1.4).at((2, 1)).label("обхід")
    return d.draw(show=False)


def solve_loop_matrix(E1, E2, R1, R2, R3, E2_reversed):
    """Second law as A @ [I] = b for the two-EMF, up-to-three-resistor loop.

    ΣE = ΣI·R for a single loop is one linear equation in one unknown,
    I. This is not a cross-check of a separate derivation -- it's the
    direct statement of ЕТ10's own law: the left side is the sum of
    signed EMFs (E2 negated when the battery is reversed), the right
    side is I times the sum of resistances along the loop. With E2=0,
    R3=0 this reduces to exactly ЕТ04's one-source series circuit (see
    et10.py's "місток до ЕТ04" cell), which is the note's own point --
    the ЕТ04 drop-sum check was this same law all along.
    """
    E1_s, E2_s, R1_s, R2_s, R3_s = (sp.Rational(x) for x in (E1, E2, R1, R2, R3))
    if E2_reversed:
        E2_s = -E2_s
    I = sp.symbols("I")
    eq = sp.Eq(E1_s + E2_s, I * (R1_s + R2_s + R3_s))
    A, b = sp.linear_eq_to_matrix([eq], [I])
    (I_v,) = A.solve(b)
    I_val = float(I_v)
    vals = {
        "I": I_val,
        "U1": I_val * float(R1_s),
        "U2": I_val * float(R2_s),
        "U3": I_val * float(R3_s),
    }
    return vals, A, b
