"""Shared drawing + cross-check helpers for ЕТ13, ЕТ14 (marimo notebooks).

ЕТ14 continues ЕТ13's exact five-resistor network (same E, R1..R5): ЕТ13
collapses it down to one equivalent resistance step by step, ЕТ14 takes
that one number and "unwinds" it back to the source current, the voltage
drop on every real section, and the power each section burns. Rather than
redraw the network from scratch inside et14.py, `draw_network5` here is
the same schemdraw geometry ЕТ13's own diagram cell builds (R1 in series,
R2 parallel to the R3+R4 series pair, then R5 in series), factored out so
both episodes draw the identical circuit from one source of truth --
et13.py itself is left untouched (it is already published and verified;
this module only mirrors its geometry so et14.py never redraws it from
scratch, per the same shared-helper convention `circuits_et04_06.py` /
`circuits_et09_10.py` already established for this course).

`solve_network_matrix` is the same node-voltage Kirchhoff solve ЕТ13's
own last cell performs (three real nodes -> A@V=b via
sympy.linear_eq_to_matrix), generalized into a function and extended to
also return the per-section voltage drops (E-V2, V2-V3, V3) so ЕТ14's
"unwinding" numbers -- not just ЕТ13's R_eq/I_src -- get an independent
cross-check too. This is the same method ЕТ09 (node currents) and ЕТ10
(loop drops) teach.

`draw_network3` is ЕТ14-only: the same network redrawn as its three real
sections after ЕТ13's collapse (R1, the parallel block R_бд, R5), each
labelled with its own live ΔU -- the "unwinding" payoff visual the note's
own scenario describes (one collapsed "десять ом" expanding back into
concrete volts and watts on concrete parts).

Every value fed into `sp.Rational` here goes through `str(x)` first, not
a bare float -- `sp.Rational(0.1)` parses the binary float noise behind
0.1, `sp.Rational("0.1")` parses the decimal string exactly. Sliders in
et14.py use 0.5-step floats, so this matters here in a way it didn't for
et13.py's original all-integer defaults.

marimo's `export html-wasm` auto-packages a local sibling import like this
one into a content-addressed wheel under `public/wheels/` (see
`circuits_et04_06.py`'s and `circuits_et09_10.py`'s docstrings for the
confirmed mechanics). lcapy is NOT imported anywhere in this module and
never will be (see `_notebooks/verify_et13.py`'s docstring for why).
"""
import schemdraw
import schemdraw.elements as elm
import sympy as sp

schemdraw.use("matplotlib")


def draw_network5(E, R1, R2, R3, R4, R5):
    """ЕТ13/ЕТ14 five-resistor network -- identical geometry to ЕТ13's own diagram cell."""
    d = schemdraw.Drawing()
    d += elm.SourceV().up().label(f"E = {E:g} В")
    d += (_R1 := elm.Resistor().right().label(f"R₁ = {R1:g} Ом"))

    d.push()
    d += elm.Line().up().length(1.5)
    d += (_R2 := elm.Resistor().right().label(f"R₂ = {R2:g} Ом"))
    d.pop()

    d += elm.Line().down().length(1.5)
    d += (_R3 := elm.Resistor().right().label(f"R₃ = {R3:g} Ом"))
    d += (_R4 := elm.Resistor().right().label(f"R₄ = {R4:g} Ом"))

    d += elm.Line().at(_R2.end).right().tox(_R4.end)
    d += elm.Line().down().toy(_R4.end)

    d += elm.Resistor().right().label(f"R₅ = {R5:g} Ом").at(_R4.end)
    d += elm.Line().down()
    d += elm.Line().left().tox(0)
    d += elm.Line().up().toy(0)
    return d.draw(show=False)


def draw_network3(E, R1, R_bd, R5, dU1, dU_bd, dU5):
    """ЕТ14: the same network drawn as its three real post-collapse sections.

    Each resistor label carries its own live ΔU -- this is the diagram
    that shows the "розкручування" payoff: one collapsed number expanding
    back into three concrete drops that must sum back to E.
    """
    d = schemdraw.Drawing()
    d += elm.SourceV().up().label(f"E = {E:g} В")
    d += elm.Resistor().right().label(f"R₁={R1:g} Ом\nΔU₁={dU1:.3g} В")
    d += elm.Resistor().right().label(f"R_бд={R_bd:.3g} Ом\nΔU_бд={dU_bd:.3g} В")
    d += elm.Resistor().right().label(f"R₅={R5:g} Ом\nΔU₅={dU5:.3g} В")
    d += elm.Line().down()
    d += elm.Line().left().tox(0)
    d += elm.Line().up().toy(0)
    return d.draw(show=False)


def solve_network_matrix(E, R1, R2, R3, R4, R5):
    """Node-voltage KVL solve of the ЕТ13/ЕТ14 network -- same method as ЕТ13's own last cell.

    Three real nodes (V2 after R1, V3 after the parallel block/before R5,
    V4 the mid-point of the R3-R4 branch); node "1" is the source's own
    E, node "0" is ground where R5 returns -- exactly ЕТ13's own
    numbering. Returns a dict with R_eq, I_src, the two parallel-branch
    currents (I_r2, I_r3, for the first-law sum check) and the three
    post-collapse section drops (dU1, dU_bd, dU5 = E-V2, V2-V3, V3) so
    callers can cross-check ЕТ14's unwound voltages, not just ЕТ13's
    collapsed resistance -- plus (A, b) so the caller can render the
    matrix.
    """
    E, R1, R2, R3, R4, R5 = (sp.Rational(str(x)) for x in (E, R1, R2, R3, R4, R5))
    V2, V3, V4 = sp.symbols("V2 V3 V4")

    eqs = [
        sp.Eq((E - V2) / R1, (V2 - V3) / R2 + (V2 - V4) / R3),  # вузол 2
        sp.Eq((V2 - V3) / R2 + (V4 - V3) / R4, V3 / R5),  # вузол 3
        sp.Eq((V2 - V4) / R3, (V4 - V3) / R4),  # вузол 4
    ]
    A, b = sp.linear_eq_to_matrix(eqs, [V2, V3, V4])
    V2v, V3v, V4v = A.solve(b)

    I_src = (E - V2v) / R1
    I_r2 = (V2v - V3v) / R2
    I_r3 = (V2v - V4v) / R3
    R_eq = E / I_src

    return {
        "R_eq": float(R_eq),
        "I_src": float(I_src),
        "I_r2": float(I_r2),
        "I_r3": float(I_r3),
        "dU1": float(E - V2v),
        "dU_bd": float(V2v - V3v),
        "dU5": float(V3v),
    }, A, b
