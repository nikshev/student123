"""Кольори графіки під поточну тему сторінки.

Ноутбук один і той самий для світлої й темної теми: marimo виконує його
в браузері вже після того, як тема відома, тому колір вибирається під час
малювання, а не запікається в експорт.

Три пастки, кожну з яких ми вже проходили:

1. Типовий колір schemdraw — літерально `"black"`. На темній темі marimo
   дає фігурі майже чорне тло, і схема ставала чорним прямокутником на
   чорному. Саме так виглядав ЕТ13 після першого переходу на темну тему.
2. `mo.app_meta().theme` повертає значення КОНФІГУ, а не показану тему.
   При `theme = "system"` це буквально рядок `"system"`, тож порівняння
   `== "dark"` мовчки давало світлі кольори на темній сторінці. Тому
   `system` доводиться доводити до кінця самим — через `matchMedia`.
3. Тло фігури лишалось білим усередині темної сторінки. Тому
   `apply()` робить фігуру прозорою: хай крізь неї видно сторінку, хоч
   яка вона.

Поза браузером (verify_*.py запускаються звичайним Python) усе
деградує до старої поведінки: чорні штрихи, типове тло.
"""

DARK_INK = "#e8e8ee"
LIGHT_INK = "black"


def _configured() -> str:
    try:
        import marimo as mo

        return mo.app_meta().theme or "light"
    except Exception:
        return "light"


def theme() -> str:
    """Тема, у якій малюємо: "light" або "dark".

    ⚠️ `"system"` тут звести нікуди: ядро marimo у WASM живе у Web
    Worker, де немає ні `window`, ні `matchMedia`, тому `import js;
    js.window.matchMedia(...)` кидає виняток (перевірено на ЕТ13 —
    схема лишилась чорною на темній сторінці). Тож `system`
    трактуємо як світлу й покладаємось на те, що конфіг задає
    конкретну тему.
    """
    configured = _configured()
    return configured if configured in ("light", "dark") else "light"


def ink() -> str:
    """Колір ліній і підписів — світлий на темній темі, чорний на світлій."""
    return DARK_INK if theme() == "dark" else LIGHT_INK


def apply() -> str:
    """Прозоре тло фігури + підписи кольором ink(). Повертає ink()."""
    colour = ink()
    try:
        import matplotlib as mpl

        mpl.rcParams.update({
            "figure.facecolor": "none",
            "axes.facecolor": "none",
            "savefig.facecolor": "none",
            "savefig.transparent": True,
            "text.color": colour,
            "axes.labelcolor": colour,
            "axes.edgecolor": colour,
            "xtick.color": colour,
            "ytick.color": colour,
            "grid.color": colour,
            "grid.alpha": 0.25,
        })
    except Exception:
        pass
    return colour
