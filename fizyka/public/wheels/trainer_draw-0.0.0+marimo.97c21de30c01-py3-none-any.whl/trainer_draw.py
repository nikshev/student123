"""Покрокові рисунки задач тренажера (як слайди практикуму) — SVG.

scene — словник, який генерує задача (trainer_fi.py); stage:
  0 — ситуація з числами умови;
  1 — сили / швидкості (підказка 1);
  2 — осі, складові, плечі (підказка 2);
  3 — шукана величина з відповіддю (розв'язок).
Кожен елемент сцени має поле "stage" — з якого кроку він з'являється.

Чому SVG, а не matplotlib: у браузері (WASM) сторінка малює ~190 рисунків;
matplotlib на цьому витрачав би хвилини, а SVG — це рядок тексту. Колір
підписів — currentColor, тож рисунок сам іде за темою сторінки.
Лише stdlib.
"""
import math

C = {"ink": "currentColor", "muted": "#8a8a96", "grid": "#8a8a9655",
     "accent": "#3a8be0", "force": "#d68a2a", "answer": "#2fa36b", "box": "none"}
ROLE = {"force": "force", "motion": "accent", "answer": "answer", "aux": "muted"}


def _esc(t):
    return str(t).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


class Canvas:
    """Полотно в «математичних» координатах (y угору) → SVG."""

    def __init__(self):
        self.els = []
        self.xlim = (-3, 3)
        self.ylim = (-2, 2)
        self.title = None

    def lim(self, x0, x1, y0, y1):
        self.xlim, self.ylim = (x0, x1), (y0, y1)

    def line(self, pts, col="ink", w=2, dash=False):
        self.els.append(("line", pts, col, w, dash))

    def arrow(self, x, y, dx, dy, col="force", w=2.6):
        self.els.append(("arrow", (x, y), (x + dx, y + dy), col, w))

    def rect(self, cx, cy, wd, ht, col="accent", w=2):
        self.els.append(("poly", [(cx - wd / 2, cy - ht / 2), (cx + wd / 2, cy - ht / 2),
                                  (cx + wd / 2, cy + ht / 2), (cx - wd / 2, cy + ht / 2)], col, w, None))

    def poly(self, pts, col="muted", w=2, fill=None):
        self.els.append(("poly", pts, col, w, fill))

    def circle(self, x, y, r, col="accent", w=2, fill=None):
        self.els.append(("circle", (x, y), r, col, w, fill))

    def ellipse(self, x, y, rx, ry, col="accent", w=2):
        self.els.append(("ellipse", (x, y), rx, ry, col, w))

    def text(self, x, y, s, col="ink", size=14, anchor="middle", bold=False):
        self.els.append(("text", (x, y), s, col, size, anchor, bold))

    def dim(self, x0, x1, y, label):
        self.els.append(("dim", x0, x1, y, label))

    def arc_arrow(self, p0, p1, bend, col="accent", w=2):
        self.els.append(("arc", p0, p1, bend, col, w))

    def svg(self, width=560):
        (x0, x1), (y0, y1) = self.xlim, self.ylim
        k = width / (x1 - x0)
        top = 28 if self.title else 0
        height = (y1 - y0) * k + top
        X = lambda x: (x - x0) * k
        Y = lambda y: top + (y1 - y) * k
        out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width:.0f} {height:.0f}" '
               f'style="max-width:100%;height:auto;font-family:system-ui,sans-serif">', "<defs>"]
        for name, col in C.items():
            out.append(f'<marker id="h-{name}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" '
                       f'markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" '
                       f'fill="{col}"/></marker>')
        out.append("</defs>")
        if self.title:
            out.append(f'<text x="{width - 4}" y="20" text-anchor="end" font-size="16" font-weight="700" '
                       f'fill="{C["answer"]}">{_esc(self.title)}</text>')
        for e in self.els:
            kind = e[0]
            if kind == "line":
                _, pts, col, w, dash = e
                d = " ".join(f"{X(x):.1f},{Y(y):.1f}" for x, y in pts)
                out.append(f'<polyline points="{d}" fill="none" stroke="{C[col]}" stroke-width="{w}"'
                           + (' stroke-dasharray="6 4"' if dash else "") + "/>")
            elif kind == "arrow":
                _, (ax_, ay), (bx, by), col, w = e
                out.append(f'<line x1="{X(ax_):.1f}" y1="{Y(ay):.1f}" x2="{X(bx):.1f}" y2="{Y(by):.1f}" '
                           f'stroke="{C[col]}" stroke-width="{w}" marker-end="url(#h-{col})"/>')
            elif kind == "poly":
                _, pts, col, w, fill = e
                d = " ".join(f"{X(x):.1f},{Y(y):.1f}" for x, y in pts)
                out.append(f'<polygon points="{d}" fill="{C[fill] if fill else "none"}" '
                           f'stroke="{C[col]}" stroke-width="{w}"/>')
            elif kind == "circle":
                _, (x, y), r, col, w, fill = e
                out.append(f'<circle cx="{X(x):.1f}" cy="{Y(y):.1f}" r="{r * k:.1f}" '
                           f'fill="{C[fill] if fill else "none"}" stroke="{C[col]}" stroke-width="{w}"/>')
            elif kind == "ellipse":
                _, (x, y), rx, ry, col, w = e
                out.append(f'<ellipse cx="{X(x):.1f}" cy="{Y(y):.1f}" rx="{rx * k:.1f}" ry="{ry * k:.1f}" '
                           f'fill="none" stroke="{C[col]}" stroke-width="{w}"/>')
            elif kind == "text":
                _, (x, y), s, col, size, anchor, bold = e
                out.append(f'<text x="{X(x):.1f}" y="{Y(y) + size * 0.35:.1f}" font-size="{size}" '
                           f'text-anchor="{anchor}" fill="{C[col]}"'
                           + (' font-weight="700"' if bold else "") + f">{_esc(s)}</text>")
            elif kind == "dim":
                _, xa, xb, y, label = e
                out.append(f'<line x1="{X(xa):.1f}" y1="{Y(y):.1f}" x2="{X(xb):.1f}" y2="{Y(y):.1f}" '
                           f'stroke="{C["muted"]}" stroke-width="1.3" marker-start="url(#h-muted)" '
                           f'marker-end="url(#h-muted)"/>')
                out.append(f'<text x="{X((xa + xb) / 2):.1f}" y="{Y(y) + 16:.1f}" font-size="13" '
                           f'text-anchor="middle" fill="{C["muted"]}">{_esc(label)}</text>')
            elif kind == "arc":
                _, (xa, ya), (xb, yb), bend, col, w = e
                mx, my = (xa + xb) / 2, (ya + yb) / 2
                nx, ny = -(yb - ya), (xb - xa)
                cx, cy = mx + nx * bend, my + ny * bend
                out.append(f'<path d="M{X(xa):.1f},{Y(ya):.1f} Q{X(cx):.1f},{Y(cy):.1f} '
                           f'{X(xb):.1f},{Y(yb):.1f}" fill="none" stroke="{C[col]}" stroke-width="{w}" '
                           f'marker-end="url(#h-{col})"/>')
        out.append("</svg>")
        return "".join(out)


def _rc(role):
    return ROLE.get(role or "force", "force")


def _items(scene, stage):
    return [it for it in scene.get("items", []) if it.get("stage", 0) <= stage]


def _box(c, x, y, w, h, label):
    c.rect(x, y, w, h)
    if label:
        c.text(x, y, label, size=14)


# --------------------------------------------------------------- типи сцен
def _body(c, sc, st):
    if sc.get("ground", "h") == "h":
        c.line([(-3, -0.55), (3, -0.55)], "muted", 2)
    _box(c, 0, 0, 1.4, 1.0, sc.get("label", ""))
    notes = [it for it in _items(sc, st) if it.get("role") == "aux"]
    for k, it in enumerate(notes):
        c.text(-3.5, 2.35 - 0.42 * k, it["text"], "muted", 14, "start")
    up_used = 0
    for it in _items(sc, st):
        if it.get("role") == "aux":
            continue
        a = math.radians(it["dir"])
        L = it.get("len", 1.6)
        col = _rc(it.get("role"))
        if it.get("role") == "motion" and it["dir"] in (0, 180):
            y = 1.05 + 0.55 * up_used
            up_used += 1
            sx = -0.6 if it["dir"] == 0 else 0.6
            c.arrow(sx, y, math.cos(a) * 1.2, 0, col)
            c.text(sx + math.cos(a) * 1.35, y, it["text"], col, 14, "start" if it["dir"] == 0 else "end")
            continue
        sx, sy = math.cos(a) * 0.72, math.sin(a) * 0.52
        c.arrow(sx, sy, math.cos(a) * L, math.sin(a) * L, col)
        ex, ey = sx + math.cos(a) * L, sy + math.sin(a) * L
        anchor = "end" if math.cos(a) < -0.3 else "start"
        c.text(ex + math.cos(a) * 0.12 + (0.15 if abs(math.cos(a)) <= 0.3 else 0),
               ey + math.sin(a) * 0.22, it["text"], col, 14, anchor)
    c.lim(-3.6, 3.6, -2.7, 2.6)


def _incline(c, sc, st):
    al = math.radians(sc["angle"])
    L = 5.0
    c.poly([(-2.5, -1.5), (-2.5 + L, -1.5), (-2.5 + L, -1.5 + L * math.tan(al))], "muted", 2)
    c.text(-1.55, -1.28, f"{sc['angle']}°", "muted", 14)
    u = (math.cos(al), math.sin(al))
    n = (-math.sin(al), math.cos(al))
    s = sc.get("pos", 2.6)
    bx, by = -2.5 + u[0] * s, -1.5 + u[1] * s
    cx, cy = bx + n[0] * 0.38, by + n[1] * 0.38
    c.poly([(bx - u[0] * .4, by - u[1] * .4), (bx + u[0] * .4, by + u[1] * .4),
            (bx + u[0] * .4 + n[0] * .76, by + u[1] * .4 + n[1] * .76),
            (bx - u[0] * .4 + n[0] * .76, by - u[1] * .4 + n[1] * .76)], "accent", 2)
    dirs = {"up": u, "down": (-u[0], -u[1]), "normal": n, "g": (0, -1), "h_out": (-1, 0)}
    for it in _items(sc, st):
        d = dirs[it["dir"]]
        Lr = it.get("len", 1.3)
        col = _rc(it.get("role"))
        c.arrow(cx, cy, d[0] * Lr, d[1] * Lr, col)
        c.text(cx + d[0] * (Lr + 0.35) + it.get("dx", 0), cy + d[1] * (Lr + 0.3) + it.get("dy", 0),
               it["text"], col, 14)
    c.lim(-3.2, 3.2, -2.1, 2.9)


def _pulley(c, sc, st):
    r = 0.35
    if sc["mode"] == "atwood":
        c.circle(0, 1.6, r, "ink")
        c.line([(0, 1.6), (0, 2.4)], "muted", 2)
        for x, y, lab in ((-r, 0.0, sc["m1"]), (r, -0.6, sc["m2"])):
            c.line([(x, 1.6), (x, y + 0.35)], "muted", 1.6)
            _box(c, x, y, 0.55, 0.7, lab)
        for it in _items(sc, st):
            x, y = (-r, 0.0) if it["who"] == 1 else (r, -0.6)
            dy = 1 if it["dir"] == "up" else -1
            ox = -0.6 if it["who"] == 1 else 0.6
            col = _rc(it.get("role"))
            c.arrow(x + ox, y + dy * 0.2, 0, dy * 0.9, col)
            c.text(x + ox + (-0.15 if ox < 0 else 0.15), y + dy * 1.3, it["text"], col, 12,
                   "end" if ox < 0 else "start")
        c.lim(-2.4, 2.4, -2.3, 2.6)
    else:
        c.line([(-3, 0), (1.2, 0)], "muted", 2)
        c.line([(1.2, 0), (1.2, -2.2)], "muted", 2)
        c.circle(1.2 + r * .7, 0.2, r, "ink")
        _box(c, -1.2, 0.4, 1.1, 0.8, sc["M"])
        c.line([(-0.65, 0.4), (1.2, 0.55)], "muted", 1.6)
        c.line([(1.2 + r * 1.4, 0.2), (1.2 + r * 1.4, -0.9)], "muted", 1.6)
        _box(c, 1.2 + r * 1.4, -1.3, 0.6, 0.7, sc["m"])
        for it in _items(sc, st):
            col = _rc(it.get("role"))
            if it["who"] == "M":
                c.arrow(-0.6, 0.95, 1.0, 0, col)
                c.text(0.55, 0.95, it["text"], col, 14, "start")
            else:
                dy = 1 if it["dir"] == "up" else -1
                c.arrow(1.2 + r * 1.4 + 0.5, -1.3 + dy * 0.2, 0, dy * 0.8, col)
                c.text(1.2 + r * 1.4 + 0.7, -1.3 + dy * 0.9, it["text"], col, 14, "start")
        c.lim(-3.2, 3.4, -2.4, 1.8)


def _before_after(c, sc, st):
    rows = sc.get("rows", ("до", "після"))
    for row, key, y in ((rows[0], "before", 1.1), (rows[1], "after", -1.1)):
        c.text(-3.4, y + 0.75, row, "muted", 14, "start")
        c.line([(-3.4, y - 0.45), (3.4, y - 0.45)], "grid", 1.5)
        for b in sc[key]:
            if b.get("stage", 0) > st:
                continue
            x = b["x"]
            if b.get("shape") == "dot":
                c.circle(x, y, 0.18, "accent", 1, fill="accent")
                if b.get("label"):
                    c.text(x, y - 0.42, b["label"], size=14)
            else:
                _box(c, x, y, b.get("w", 1.0), 0.7, b["label"])
            v = b.get("v")
            if v and v.get("stage", 0) <= st:
                L = max(0.5, min(1.6, abs(v["len"])))
                d = 1 if v["len"] > 0 else -1
                sx = x + d * (b.get("w", 1.0) / 2 + 0.05) if b.get("shape") != "dot" else x + d * 0.22
                col = _rc(v.get("role", "motion"))
                c.arrow(sx, y, d * L, 0, col)
                c.text(sx + d * L / 2, y + 0.42, v["text"], col, 14)
    c.lim(-3.6, 3.6, -2.2, 2.3)


def _vectors(c, sc, st):
    if st >= 2 and sc.get("axes"):
        c.line([(-2.6, 0), (2.6, 0)], "grid", 1)
        c.line([(0, -2.4), (0, 2.4)], "grid", 1)
        c.text(2.75, -0.35, sc["axes"][0], "muted", 14)
        c.text(-0.45, 2.45, sc["axes"][1], "muted", 14)
    c.circle(0, 0, 0.1, "ink", 1, fill="ink")
    for it in _items(sc, st):
        a = math.radians(it["dir"])
        L = it.get("len", 1.8)
        col = _rc(it.get("role", "motion"))
        c.arrow(0, 0, math.cos(a) * L, math.sin(a) * L, col)
        c.text(math.cos(a) * (L + 0.5), math.sin(a) * (L + 0.35) + 0.05, it["text"], col, 14)
    c.lim(-3.2, 3.2, -2.6, 2.7)


def _points(c, sc, st):
    if sc.get("rod"):
        c.line([(-0.2, 0), (sc["rod"] + 0.2, 0)], "muted", 5)
        c.line([(0, -0.9), (0, 0.9)], "force", 2, dash=True)
        c.text(0, 1.1, "вісь", "force", 14)
    else:
        xs = [p["x"] for p in sc["pts"]]
        ys = [p["y"] for p in sc["pts"]]
        c.line([(min(xs) - 0.8, 0), (max(xs) + 0.8, 0)], "grid", 1)
        c.line([(0, min(ys) - 0.8), (0, max(ys) + 0.8)], "grid", 1)
    for k, p in enumerate(sc["pts"]):
        c.circle(p["x"], p["y"], 0.14, "accent", 1, fill="accent")
        c.text(p["x"], p["y"] + 0.42, p["label"], size=14)
        if st >= 2 and sc.get("rod"):
            c.dim(0, p["x"], -0.45 - 0.5 * k, p["r"])
    if st >= 3 and sc.get("cm"):
        x, y = sc["cm"]
        c.text(x, y, "✕", "answer", 18, bold=True)
        c.text(x + 0.3, y - 0.4, "центр мас", "answer", 14, "start")
    xs = [p["x"] for p in sc["pts"]] + [0]
    ys = [p["y"] for p in sc["pts"]] + [0]
    c.lim(min(xs) - 1, max(xs) + 1.6, min(ys) - 1.9, max(ys) + 1.2)


def _lever(c, sc, st):
    L = sc["L"]
    c.line([(0, 0), (L, 0)], "accent", 7)
    for x in sc.get("supports", []):
        c.poly([(x, -0.06), (x - 0.25 * L / 6, -0.6), (x + 0.25 * L / 6, -0.6)], "muted", 1, fill="muted")
    if sc.get("pivot") is not None:
        c.circle(sc["pivot"], 0, 0.07 * L / 3, "force", 1, fill="force")
    if sc.get("disk_end"):
        c.ellipse(L, 0, 0.18, 0.8)
    downs = sorted([it for it in _items(sc, st) if it.get("dir", "down") == "down"], key=lambda i: i["x"])
    ups = sorted([it for it in _items(sc, st) if it.get("dir") == "up"], key=lambda i: i["x"])
    for k, it in enumerate(downs):
        col = _rc(it.get("role"))
        c.arrow(it["x"], 1.3, 0, -1.2, col)
        c.text(it["x"], 1.55 + 0.35 * (k % 2), it["text"], col, 14)
    for k, it in enumerate(ups):
        col = _rc(it.get("role"))
        c.arrow(it["x"], -1.3, 0, 1.2, col)
        c.text(it["x"], -1.55 - 0.35 * (k % 2), it["text"], col, 14)
    if st >= 2:
        for j, (x0, x1, lab) in enumerate(sc.get("dims", [])):
            c.dim(x0, x1, -2.35 - 0.45 * j, lab)
    c.lim(-0.8, L + 0.8, -3.4, 2.2)


def _disk(c, sc, st):
    R = 1.6
    c.circle(0, 0, R, "accent", 2.5)
    c.circle(0, 0, 0.06, "ink", 1, fill="ink")
    c.text(0, -R - 0.35, sc.get("label", ""), size=14)
    c.arc_arrow((R * 1.15, R * 0.45), (R * 0.45, R * 1.15), -0.35, "accent")
    c.text(R * 0.75, R * 1.38, sc.get("w", "ω"), "accent", 14, "start")
    for m in sc.get("masses", []):
        if m.get("stage", 0) > st:
            continue
        c.circle(m["x"], m["y"], 0.16, "force", 1, fill="force")
        c.text(m["x"], m["y"] + 0.4, m["label"], size=14)
    for it in _items(sc, st):
        col = _rc(it.get("role", "motion" if it.get("kind") == "v" else "force"))
        if it.get("kind") == "v":
            c.arrow(it["x"], it["y"], it["dx"], it["dy"], col)
            c.text(it["x"] + it["dx"] + 0.1, it["y"] + it["dy"] + 0.25, it["text"], col, 14, "start")
        elif it.get("kind") == "R":
            c.line([(0, 0), (R, 0)], "muted", 1.4, dash=True)
            c.text(R / 2, -0.28, it["text"], "muted", 13)
        elif it.get("kind") == "M":
            c.arc_arrow((-R * 1.15, R * 0.45), (-R * 0.45, R * 1.15), 0.35, col)
            c.text(-R * 0.75, R * 1.38, it["text"], col, 14, "end")
    c.lim(-3.4, 3.4, -2.3, 2.6)


def _pendulum(c, sc, st):
    th = math.radians(sc["angle"])
    c.poly([(-2.6, -1.6), (2.6, -1.6), (2.6, 2.0), (-2.6, 2.0)], "muted", 2)
    c.arrow(-1.0, 2.35, 2.0, 0, "accent")
    c.text(1.25, 2.35, "a = ?", "accent", 14, "start")
    px, py = 0.0, 1.9
    bx, by = px - 2.2 * math.sin(th), py - 2.2 * math.cos(th)
    c.line([(px, py), (px, py - 2.4)], "grid", 1, dash=True)
    c.line([(px, py), (bx, by)], "ink", 1.6)
    c.circle(bx, by, 0.15, "accent", 1, fill="accent")
    c.text(px + 0.35, py - 0.7, f"{sc['angle']}°", "muted", 14)
    for it in _items(sc, st):
        d = {"T": (math.sin(th), math.cos(th)), "g": (0, -1), "in": (-1, 0)}[it["dir"]]
        col = _rc(it.get("role"))
        c.arrow(bx, by, d[0] * 1.1, d[1] * 1.1, col)
        c.text(bx + d[0] * 1.45, by + d[1] * 1.4, it["text"], col, 14)
    c.lim(-2.9, 2.9, -1.9, 2.8)


def _rocket(c, sc, st):
    c.poly([(-0.6, -0.4), (1.2, -0.4), (1.8, 0), (1.2, 0.4), (-0.6, 0.4)], "accent", 2)
    c.text(0.4, 0, sc.get("label", ""), size=14)
    c.arrow(-0.7, 0, -1.6, 0, "force")
    c.text(-1.5, 0.4, sc.get("u", "u"), "force", 14)
    for it in _items(sc, st):
        col = _rc(it.get("role", "motion"))
        c.arrow(1.9, 0, 1.2, 0, col)
        c.text(2.5, 0.4, it["text"], col, 14)
    c.lim(-2.8, 3.6, -1.3, 1.3)


def _rails(c, sc, st):
    for x in (-0.35, 0.35):
        c.line([(x, -2), (x, 2)], "muted", 3)
    c.text(0, 2.3, "північ ↑", "muted", 14)
    c.arrow(0, -1.2, 0, 2.2, "accent")
    c.text(-0.6, 0.9, sc["v"], "accent", 14, "end")
    for it in _items(sc, st):
        col = _rc(it.get("role"))
        c.arrow(0.4, 0, 1.3, 0, col)
        c.text(1.0, 0.4, it["text"], col, 14)
    c.lim(-2.6, 2.8, -2.4, 2.6)


def _curve(c, sc, st):
    c.circle(0, 0, 2.0, "muted", 2)
    c.circle(0, 0, 0.06, "ink", 1, fill="ink")
    c.text(-0.9, 0.25, sc["R"], "muted", 14)
    c.line([(0, 0), (0, -2.0)], "grid", 1)
    c.rect(0, -2.0, 0.6, 0.4)
    for it in _items(sc, st):
        col = _rc(it.get("role", "motion" if it["dir"] == "v" else "force"))
        if it["dir"] == "v":
            c.arrow(0.35, -2.0, 1.4, 0, col)
            c.text(1.9, -2.0, it["text"], col, 14, "start")
        else:
            c.arrow(0, -1.75, 0, 1.0, col)
            c.text(0.2, -0.95, it["text"], col, 14, "start")
    c.lim(-2.8, 3.4, -2.8, 2.6)


KINDS = {"body": _body, "incline": _incline, "pulley": _pulley, "before_after": _before_after,
         "vectors": _vectors, "points": _points, "lever": _lever, "disk": _disk,
         "pendulum": _pendulum, "rocket": _rocket, "rails": _rails, "curve": _curve}


def _strip_answers(obj):
    """Відповідь показується заголовком — стрілки «відповіді» в самій сцені не малюємо."""
    if isinstance(obj, dict):
        return {k: _strip_answers(v) for k, v in obj.items()
                if not (k == "v" and isinstance(v, dict) and v.get("role") == "answer")}
    if isinstance(obj, list):
        return [_strip_answers(x) for x in obj
                if not (isinstance(x, dict) and (x.get("role") == "answer"
                        or (x.get("shape") == "dot" and not x.get("label") and x.get("stage", 0) >= 3)))]
    return obj


def svg(scene, stage, answer_text=None):
    """SVG-рядок рисунка на кроці stage."""
    c = Canvas()
    KINDS[scene["kind"]](c, _strip_answers(scene), stage)
    if stage >= 3 and answer_text:
        c.title = f"Відповідь: {answer_text}"
    return c.svg()
