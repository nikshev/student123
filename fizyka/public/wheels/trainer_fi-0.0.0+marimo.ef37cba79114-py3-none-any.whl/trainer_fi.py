"""Тренажер задач ФІ11–ФІ13 за мотивами OpenStax University Physics, Vol. 1.

Кожна задача — функція gen(rng) → dict. Числа випадкові (rng), тож
відповідь не запам'ятаєш — доведеться рахувати. Тип і ситуація задачі —
з OpenStax (номер і посилання в полі "src"), розв'язок і числа — наші.

Ліцензія похідної роботи: CC BY-NC-SA 4.0, як і в оригіналу
(див. ATTRIBUTION). Лише stdlib — модуль пакується у WASM-ноутбук.
"""
import math

G = 9.81
BOOK = "https://openstax.org/books/university-physics-volume-1/pages/1-introduction"
ATTRIBUTION = (
    "Задачі — за мотивами *University Physics Volume 1* (William Moebs, Samuel J. Ling, "
    "Jeff Sanny; OpenStax, Rice University, 2016), ліцензія "
    "[CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). "
    f"Access for free at {BOOK}. Умови перекладено й змінено (нові числа, підказки, "
    "розв'язки); тренажер поширюється на тих самих умовах CC BY-NC-SA 4.0, некомерційно."
)


def chap(n):
    return f"https://openstax.org/books/university-physics-volume-1/pages/{n}-problems"


def f(x, d=2):
    """Число по-українськи: кома, без зайвих нулів, справжній мінус."""
    if abs(x) >= 1e5 or (0 < abs(x) < 1e-3):
        m, e = f"{x:.{max(d, 2)}e}".split("e")
        if "." in m:
            m = m.rstrip("0").rstrip(".")
        sup = str(int(e)).translate(str.maketrans("-0123456789", "⁻⁰¹²³⁴⁵⁶⁷⁸⁹"))
        return f"{m.replace('.', ',').replace('-', '−')}·10{sup}"
    s = f"{x:.{d}f}"
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return s.replace(".", ",").replace("-", "−")


_SCENE = [None]


def _scene(sc):
    """Сцена для покрокового рисунка (trainer_draw.py) — ставиться перед P(...)."""
    _SCENE[0] = sc


def nice(x):
    """Відповідь на рисунку: 3 значущі цифри, без хвоста нулів."""
    if x == 0:
        return "0"
    d = max(0, 2 - int(math.floor(math.log10(abs(x)))))
    return f(round(x, d), d)


def P(title, ref, src, level, text, ask, answer, unit, hints, solution, tol=0.02):
    sc, _SCENE[0] = _SCENE[0], None
    return dict(title=title, ref=ref, src=src, level=level, text=text, ask=ask,
                answer=answer, unit=unit, hints=hints, solution=solution, tol=tol, scene=sc)


def pick(rng, *vals):
    return rng.choice(vals)


# ======================================================================= ФІ11
def f11_sprinter(rng):
    m = pick(rng, 55, 60, 63, 68, 72, 80)
    a = pick(rng, 3.2, 3.6, 4.0, 4.2, 4.5)
    F = m * a
    _scene(dict(kind="body", label=f"{m} кг", items=[dict(dir=0, text=f"a = {f(a)}", role="motion", stage=0), dict(dir=0, text="F = ?", stage=1, len=1.2), dict(dir=0, text=f"F = {f(F, 0)} Н", role="answer", stage=3, len=1.2)]))
    return P("Сила, що розганяє спринтера", "ФІ11, ч. 4", ("5.24", chap(5)), 1,
             f"Спринтер масою **m = {m} кг** на старті розганяється з прискоренням "
             f"**a = {f(a)} м/с²**. Яка сумарна зовнішня сила **F** на нього діє?",
             "F, Н", F, "Н",
             ["Другий закон Ньютона: сума сил визначає прискорення.",
              "**F = m·a** — сила (Н) дорівнює масі (кг), помноженій на прискорення (м/с²).",
              f"F = {m} · {f(a)}"],
             f"F = m·a = {m} · {f(a)} = **{f(F, 1)} Н**. Це сума всіх сил — тут насамперед сила "
             "тертя доріжки, якою вона штовхає ноги вперед.")


def f11_car(rng):
    v_kmh = pick(rng, 72, 90, 100, 108)
    t = pick(rng, 8, 10, 12)
    m = pick(rng, 1100, 1300, 1500, 1800)
    v = v_kmh / 3.6
    a = v / t
    F = m * a
    _scene(dict(kind="body", label=f"{m} кг", items=[dict(dir=0, text=f"0 → {v_kmh} км/год за {t} с", role="motion", stage=0, len=1.4), dict(dir=180, text="F = m·a", stage=1, len=1.2), dict(dir=90, text=f"v = {f(v)} м/с", role="aux", stage=2, len=1.0), dict(dir=-90, text=f"F ≈ {f(F, 0)} Н", role="answer", stage=3, len=1.0)]))
    return P("Розгін автомобіля", "ФІ11, ч. 4", ("5.34", chap(5)), 1,
             f"Автомобіль масою **m = {m} кг** розганяється з місця до **v = {v_kmh} км/год** "
             f"за **t = {t} с**. Яка сумарна сила на нього діє?",
             "F, Н", F, "Н",
             ["Спершу кінематика (прискорення), потім ІІ закон.",
              "**a = (v − v₀) ÷ t**, v₀ = 0 — старт з місця; **F = m·a**. "
              "Швидкість переведи в м/с: поділи км/год на 3,6.",
              f"v = {v_kmh} ÷ 3,6 = {f(v)} м/с; a = {f(v)} ÷ {t}; F = {m} · a"],
             f"v = {v_kmh} ÷ 3,6 ≈ {f(v)} м/с; a = v ÷ t ≈ {f(a, 3)} м/с²; "
             f"F = m·a ≈ {m} · {f(a, 3)} ≈ **{f(F, 0)} Н**.")


def f11_braking(rng):
    v_kmh = pick(rng, 54, 72, 90)
    d = pick(rng, 30, 40, 50, 60)
    m = pick(rng, 1200, 1400, 1600)
    v = v_kmh / 3.6
    a = v ** 2 / (2 * d)
    F = m * a
    _scene(dict(kind="body", label=f"{m} кг", items=[dict(dir=0, text=f"v₀ = {v_kmh} км/год", role="motion", stage=0), dict(dir=180, text="F гальм. = ?", stage=1), dict(dir=-90, text=f"s = {d} м", role="aux", stage=2, len=1.0), dict(dir=150, text=f"F ≈ {f(F, 0)} Н", role="answer", stage=3, len=1.2)]))
    return P("Гальмування на відстані", "ФІ11, ч. 4 · ФІ05", ("5.35", chap(5)), 2,
             f"Автомобіль масою **m = {m} кг** їде зі швидкістю **v₀ = {v_kmh} км/год** і "
             f"гальмує до зупинки на шляху **s = {d} м**. Яка (за модулем) сумарна гальмівна сила?",
             "F, Н", F, "Н",
             ["Час не дано — потрібна формула кінематики без часу.",
              "**v² = v₀² − 2·a·s** — для рівносповільненого руху; при v = 0 маємо **a = v₀² ÷ (2s)**. "
              "Далі **F = m·a**. v₀ — у м/с.",
              f"v₀ = {v_kmh} ÷ 3,6 = {f(v)} м/с; a = {f(v)}² ÷ (2 · {d})"],
             f"v₀ ≈ {f(v)} м/с; a = v₀² ÷ (2s) ≈ {f(a, 3)} м/с²; F = m·a ≈ **{f(F, 0)} Н**.")


def f11_push_up(rng):
    m = pick(rng, 1.5, 2.0, 2.5, 3.0)
    Fp = pick(rng, 25, 30, 35, 40)
    a = Fp / m - G
    _scene(dict(kind="body", ground="v", label=f"{f(m)} кг", items=[dict(dir=90, text=f"F = {Fp} Н", stage=0), dict(dir=-90, text="m·g", stage=1), dict(dir=0, text="вісь угору", role="aux", stage=2, len=0.01), dict(dir=150, text=f"a ≈ {f(a)}", role="answer", stage=3, len=1.1)]))
    return P("Тіло штовхають угору", "ФІ11, ч. 4", ("5.45", chap(5)), 1,
             f"Тіло масою **m = {f(m)} кг** штовхають вертикально вгору силою **F = {Fp} Н**. "
             "З яким прискоренням воно рухається? (g = 9,81 м/с²)",
             "a, м/с²", a, "м/с²",
             ["На тіло діють ДВІ сили: твоя вгору і сила тяжіння вниз.",
              "**m·a = F − m·g** — ІІ закон, вісь угору; m·g — сила тяжіння, g = 9,81 м/с².",
              f"a = ({Fp} − {f(m)} · 9,81) ÷ {f(m)}"],
             f"m·a = F − m·g → a = F/m − g = {Fp}/{f(m)} − 9,81 ≈ **{f(a)} м/с²**. "
             "Поширена помилка — забути силу тяжіння і отримати F/m.")


def f11_moon(rng):
    Wm = pick(rng, 150, 200, 250, 300)
    gm = 1.62
    m = Wm / gm
    We = m * G
    _scene(dict(kind="before_after", rows=("Місяць", "Земля"), before=[dict(x=0, label="космонавт", w=1.6, v=dict(len=-1.0, text=f"P = {Wm} Н, g = 1,62", role="force"))], after=[dict(x=0, label="та сама m", w=1.6, v=dict(len=-1.0, text="P = ?  g = 9,81", role="force", stage=1))]))
    return P("Вага на Місяці й на Землі", "ФІ11, ч. 3", ("5.41", chap(5)), 1,
             f"Космонавт у скафандрі важить на Місяці **P = {Wm} Н**. Скільки він важитиме на "
             "Землі? (на Місяці g = 1,62 м/с², на Землі 9,81 м/с²)",
             "P на Землі, Н", We, "Н",
             ["Маса — міра інертності — однакова скрізь; вага — це m·g, вона залежить від g.",
              "**m = P ÷ g_Місяця**, потім **P_Землі = m·g_Землі**.",
              f"m = {Wm} ÷ 1,62; P = m · 9,81"],
             f"m = {Wm} ÷ 1,62 ≈ {f(m, 1)} кг — та сама й на Землі; P = m·g ≈ **{f(We, 0)} Н**.")


def f11_truck_car(rng):
    mt = pick(rng, 8000, 10000, 12000)
    mc = pick(rng, 1000, 1200, 1500)
    at = pick(rng, 4.0, 5.0, 6.0)
    ac = mt * at / mc
    _scene(dict(kind="before_after", rows=("удар", "сили"), before=[dict(x=-1.6, label=f"{mt} кг", w=1.6, v=dict(len=1.2, text=f"гальмує, a = {f(at)}", role="motion")), dict(x=1.4, label=f"{mc} кг", w=1.0)], after=[dict(x=-1.0, label="вантажівка", w=1.4, v=dict(len=-1.0, text="F", role="force", stage=1)), dict(x=1.2, label="легковик", w=1.2, v=dict(len=1.0, text="F", role="force", stage=1))]))
    return P("Вантажівка врізається в легковик", "ФІ11, ч. 5", ("5.54", chap(5)), 2,
             f"Вантажівка масою **{mt} кг** врізається в легковик масою **{mc} кг**. Під час "
             f"удару вантажівка гальмує з прискоренням **{f(at)} м/с²**. Яке прискорення "
             "легковика (за модулем)?",
             "a легковика, м/с²", ac, "м/с²",
             ["ІІІ закон: сили взаємодії однакові за модулем.",
              "**F = m_вантажівки · a_вантажівки = m_легковика · a_легковика** — одна сила, різні маси.",
              f"a = {mt} · {f(at)} ÷ {mc}"],
             f"F = {mt} · {f(at)} = {f(mt * at, 0)} Н діє на обидва; a = F ÷ {mc} ≈ **{f(ac, 1)} м/с²** "
             "— у стільки разів більше, у скільки легковик легший.")


def f11_trampoline(rng):
    m = pick(rng, 40, 45, 50, 55)
    a = pick(rng, 5.0, 6.0, 7.5, 8.0)
    N = m * (G + a)
    _scene(dict(kind="body", label=f"{m} кг", items=[dict(dir=60, text=f"a = {f(a)}", role="motion", stage=0, len=1.2), dict(dir=90, text="N = ?", stage=1), dict(dir=-90, text="m·g", stage=1), dict(dir=120, text=f"N ≈ {f(N, 0)} Н", role="answer", stage=3, len=1.4)]))
    return P("Батут підкидає гімнастку", "ФІ11, ч. 4", ("5.58", chap(5)), 1,
             f"З якою силою батут має діяти на гімнастку масою **{m} кг**, щоб вона рухалась "
             f"угору з прискоренням **{f(a)} м/с²**?",
             "N, Н", N, "Н",
             ["Батут має і втримати вагу, і розганяти.",
              "**m·a = N − m·g** → **N = m·(g + a)**; N — сила батута, g = 9,81 м/с².",
              f"N = {m} · (9,81 + {f(a)})"],
             f"N = m·(g + a) = {m} · {f(G + a)} ≈ **{f(N, 0)} Н**.")


def f11_crate_incline(rng):
    m = pick(rng, 50, 80, 100)
    al = pick(rng, 20, 30, 35)
    a = pick(rng, 1.0, 1.5, 2.0)
    F = m * (a + G * math.sin(math.radians(al)))
    _scene(dict(kind="incline", angle=al, items=[dict(dir="up", text="F = ?", stage=0), dict(dir="g", text="m·g", stage=1), dict(dir="normal", text="N", stage=1), dict(dir="down", text="m·g·sin α", role="aux", stage=2, len=1.0), dict(dir="up", text=f"F ≈ {f(F, 0)} Н", role="answer", stage=3, len=2.0, dy=0.35)]))
    return P("Ящик угору гладкою похилою", "ФІ11, ч. 4", ("5.66", chap(5)), 2,
             f"Ящик масою **{m} кг** тягнуть угору гладкою похилою площиною з кутом "
             f"**α = {al}°** силою, паралельною площині. Ящик рухається з прискоренням "
             f"**{f(a)} м/с²**. Яка ця сила?",
             "F, Н", F, "Н",
             ["Уздовж схилу на ящик тягне вниз частина сили тяжіння.",
              "**m·a = F − m·g·sin α** — m·g·sin α — складова ваги вздовж схилу.",
              f"F = {m} · ({f(a)} + 9,81 · sin {al}°)"],
             f"sin {al}° ≈ {f(math.sin(math.radians(al)), 3)}; F = m·(a + g·sin α) ≈ **{f(F, 0)} Н**.")


def f11_incline_time(rng):
    L = pick(rng, 20, 30, 40)
    al = pick(rng, 15, 20, 25)
    a = G * math.sin(math.radians(al))
    t = math.sqrt(2 * L / a)
    _scene(dict(kind="incline", angle=al, pos=4.0, items=[dict(dir="down", text=f"L = {L} м", role="motion", stage=0, len=1.6), dict(dir="g", text="m·g", stage=1), dict(dir="normal", text="N", stage=1), dict(dir="down", text="g·sin α", role="aux", stage=2, len=0.9, dy=-0.4), dict(dir="up", text=f"t ≈ {f(t)} с", role="answer", stage=3, len=0.01)]))
    return P("Візок скочується без тертя", "ФІ11, ч. 4 · ФІ05", ("6.41", chap(6)), 2,
             f"Візок починає з місця рух униз гладкою похилою доріжкою довжиною **L = {L} м** з "
             f"кутом **α = {al}°**. За який час він доїде донизу?",
             "t, с", t, "с",
             ["Спершу прискорення (ІІ закон уздовж схилу), потім кінематика.",
              "**a = g·sin α** (без тертя маса скорочується); **L = a·t²/2** → **t = √(2L/a)**.",
              f"a = 9,81 · sin {al}°; t = √(2 · {L} ÷ a)"],
             f"a = g·sin α ≈ {f(a, 3)} м/с²; t = √(2L/a) ≈ **{f(t)} с**.")


def f11_table_hanging(rng):
    M = pick(rng, 3.0, 4.0, 5.0)
    m = pick(rng, 0.5, 1.0, 1.5)
    a = m * G / (M + m)
    _scene(dict(kind="pulley", mode="table", M=f"{f(M)} кг", m=f"{f(m)} кг", items=[dict(who="M", text="T", stage=1), dict(who="m", dir="up", text="T", stage=1), dict(who="m", dir="down", text="m·g", stage=2), dict(who="M", text=f"a ≈ {f(a)}", role="answer", stage=3)]))
    return P("Брусок на столі й вантаж на нитці", "ФІ11, ч. 4–5", ("6.43", chap(6)), 2,
             f"Брусок масою **M = {f(M)} кг** лежить на гладкому столі; нитка через блок на "
             f"краю стола тягне його до вантажу **m = {f(m)} кг**, що висить. З яким "
             "прискоренням рухаються тіла?",
             "a, м/с²", a, "м/с²",
             ["Два тіла, одна нитка — одне прискорення і один натяг.",
              "**M·a = T** (брусок), **m·a = m·g − T** (вантаж); додай рівняння — T скоротиться.",
              f"a = {f(m)} · 9,81 ÷ ({f(M)} + {f(m)})"],
             f"a = m·g ÷ (M + m) ≈ **{f(a)} м/с²**; натяг T = M·a ≈ {f(M * a)} Н.")


def f11_atwood(rng):
    m1 = pick(rng, 1.0, 2.0, 3.0)
    m2 = m1 + pick(rng, 1.0, 2.0)
    T = 2 * m1 * m2 * G / (m1 + m2)
    _scene(dict(kind="pulley", mode="atwood", m1=f"{f(m1)}", m2=f"{f(m2)}", items=[dict(who=1, dir="up", text="T", stage=1), dict(who=2, dir="up", text="T", stage=1), dict(who=1, dir="down", text="m₁g", stage=2), dict(who=2, dir="down", text="m₂g", stage=2), dict(who=1, dir="up", text=f"T ≈ {f(T)} Н", role="answer", stage=3)]))
    return P("Машина Атвуда: натяг", "ФІ11, ч. 4–5", ("6.42", chap(6)), 2,
             f"Через нерухомий невагомий блок перекинуто нитку з вантажами **m₁ = {f(m1)} кг** і "
             f"**m₂ = {f(m2)} кг**. Який натяг нитки T під час руху?",
             "T, Н", T, "Н",
             ["Запиши ІІ закон для кожного вантажу; знайди a, потім T.",
              "**m₂·a = m₂g − T**, **m₁·a = T − m₁g** → a = g(m₂ − m₁)/(m₁ + m₂), **T = m₁(g + a)**.",
              f"a = 9,81 · {f(m2 - m1)} ÷ {f(m1 + m2)}; T = {f(m1)} · (9,81 + a)"],
             f"a ≈ {f(G * (m2 - m1) / (m1 + m2), 3)} м/с²; T = m₁(g + a) = 2m₁m₂g/(m₁ + m₂) ≈ **{f(T)} Н** "
             "— між вагами двох вантажів.")


def f11_crate_friction(rng):
    m = pick(rng, 80, 100, 120)
    mus = pick(rng, 0.4, 0.5, 0.6)
    F = mus * m * G
    _scene(dict(kind="body", label=f"{m} кг", items=[dict(dir=0, text="F", stage=0), dict(dir=180, text=f"Fтер ≤ μN, μ = {f(mus)}", stage=1), dict(dir=90, text="N = m·g", stage=2, len=1.2), dict(dir=-90, text="m·g", stage=2, len=1.2), dict(dir=30, text=f"F ≈ {f(F, 0)} Н", role="answer", stage=3, len=1.3)]))
    return P("Скільки треба, щоб зрушити ящик", "ФІ11, ч. 4", ("6.48", chap(6)), 1,
             f"Ящик масою **{m} кг** стоїть на підлозі; коефіцієнт тертя спокою **μ = {f(mus)}**. "
             "Яку найбільшу горизонтальну силу можна прикласти, щоб ящик ще не рушив?",
             "F, Н", F, "Н",
             ["Тертя спокою має межу.",
              "**F_max = μ·N**, на горизонталі **N = m·g** — μ — коефіцієнт тертя спокою, N — реакція підлоги.",
              f"F = {f(mus)} · {m} · 9,81"],
             f"F_max = μ·m·g ≈ **{f(F, 0)} Н**; більша сила — і ящик поїде.")


def f11_parcel(rng):
    al = pick(rng, 10, 15, 20)
    mu = pick(rng, 0.05, 0.10, 0.15)
    a = G * (math.sin(math.radians(al)) - mu * math.cos(math.radians(al)))
    _scene(dict(kind="incline", angle=al, items=[dict(dir="down", text="a = ?", role="motion", stage=0, len=1.2), dict(dir="g", text="m·g", stage=1), dict(dir="normal", text="N", stage=1), dict(dir="up", text=f"Fтер = μN, μ = {f(mu)}", stage=1, len=1.0), dict(dir="down", text="g·sin α − μg·cos α", role="aux", stage=2, len=0.6, dy=-0.5), dict(dir="down", text=f"a ≈ {f(a, 3)}", role="answer", stage=3, len=2.0, dy=-0.4)]))
    return P("Посилка ковзає по схилу", "ФІ11, ч. 4", ("6.55", chap(6)), 2,
             f"Посилка ковзає вниз похилою площиною з кутом **α = {al}°**; коефіцієнт тертя "
             f"ковзання **μ = {f(mu)}**. З яким прискоренням вона рухається?",
             "a, м/с²", a, "м/с²",
             ["Уздовж схилу: тягне частина ваги, гальмує тертя.",
              "**a = g·(sin α − μ·cos α)** — g·sin α тягне вниз, μ·g·cos α — тертя (N = m·g·cos α).",
              f"a = 9,81 · (sin {al}° − {f(mu)} · cos {al}°)"],
             f"a = g(sin α − μcos α) ≈ **{f(a, 3)} м/с²**; маса скоротилась.")


def f11_elevator(rng):
    m = pick(rng, 1200, 1500, 1700)
    a = pick(rng, 0.8, 1.0, 1.2, 1.5)
    T = m * (G + a)
    _scene(dict(kind="body", ground="v", label=f"{m} кг", items=[dict(dir=60, text=f"a = {f(a)}", role="motion", stage=0, len=1.2), dict(dir=90, text="T = ?", stage=1), dict(dir=-90, text="m·g", stage=1), dict(dir=120, text=f"T ≈ {f(T, 0)} Н", role="answer", stage=3, len=1.4)]))
    return P("Трос ліфта, що розганяється вгору", "ФІ11, ч. 4", ("6.37", chap(6)), 1,
             f"Кабіна ліфта масою **{m} кг** розганяється вгору з прискоренням **{f(a)} м/с²**. "
             "Який натяг троса?",
             "T, Н", T, "Н",
             ["Трос тримає вагу й ще розганяє.",
              "**m·a = T − m·g** → **T = m·(g + a)**.",
              f"T = {m} · (9,81 + {f(a)})"],
             f"T = m·(g + a) ≈ **{f(T, 0)} Н** — більше за вагу {f(m * G, 0)} Н.")


def f11_scale_elevator(rng):
    a = pick(rng, 2.0, 3.0, 3.8)
    W = pick(rng, 40, 50, 60)
    m = W / (G - a)
    _scene(dict(kind="body", ground="v", label="рюкзак", items=[dict(dir=-60, text=f"a = {f(a)} вниз", role="motion", stage=0, len=1.2), dict(dir=90, text=f"N = {W} Н", stage=1), dict(dir=-90, text="m·g", stage=1), dict(dir=150, text=f"m ≈ {f(m)} кг", role="answer", stage=3, len=1.2)]))
    return P("Ваги в ліфті, що прискорюється вниз", "ФІ11, ч. 4, 6", ("6.39", chap(6)), 2,
             f"Рюкзак стоїть на вагах у ліфті, який прискорюється вниз з **a = {f(a)} м/с²**. "
             f"Ваги показують **{W} Н**. Яка маса рюкзака?",
             "m, кг", m, "кг",
             ["Ваги показують силу реакції N, а не m·g.",
              "Вниз: **m·a = m·g − N** → **m = N ÷ (g − a)**; у системі ліфта — те саме через силу інерції (ФІ11, ч. 6).",
              f"m = {W} ÷ (9,81 − {f(a)})"],
             f"m = N ÷ (g − a) ≈ **{f(m)} кг**; у спокої ваги показали б {f(m * G, 0)} Н.")


def f11_pendulum_car(rng):
    th = pick(rng, 10, 15, 20, 25)
    a = G * math.tan(math.radians(th))
    _scene(dict(kind="pendulum", angle=th, items=[dict(dir="T", text="T", stage=1), dict(dir="g", text="m·g", stage=1), dict(dir="in", text="−m·a", stage=2)]))
    return P("Кулька на нитці у вагоні", "ФІ11, ч. 6", ("6.38", chap(6)), 2,
             f"У вагоні, що розганяється, кулька на нитці відхилилась від вертикалі на "
             f"**θ = {th}°** і висить нерухомо відносно вагона. З яким прискоренням рухається вагон?",
             "a, м/с²", a, "м/с²",
             ["У системі вагона: сила інерції −m·a, сила тяжіння і натяг врівноважуються.",
              "**tg θ = a ÷ g** → **a = g·tg θ**: горизонтальна й вертикальна складові натягу.",
              f"a = 9,81 · tg {th}°"],
             f"a = g·tg θ ≈ **{f(a)} м/с²**. З перону: горизонтальна складова натягу розганяє кульку.")


def f11_curve(rng):
    R = pick(rng, 50, 65, 80, 100)
    mu = pick(rng, 0.5, 0.6, 0.7)
    v = math.sqrt(mu * G * R)
    _scene(dict(kind="curve", R=f"R = {R} м", items=[dict(dir="v", text="v = ?", stage=0), dict(dir="c", text=f"Fтер = μmg, μ = {f(mu)}", stage=1), dict(dir="v", text=f"v ≈ {f(v, 1)} м/с", role="answer", stage=3)]))
    return P("Поворот без нахилу: гранична швидкість", "ФІ11, ч. 4 · ФІ07", ("6.77", chap(6)), 2,
             f"Автомобіль проходить горизонтальний поворот радіусом **R = {R} м**; коефіцієнт "
             f"тертя спокою шин об дорогу **μ = {f(mu)}**. Яка найбільша швидкість без заносу?",
             "v, м/с", v, "м/с",
             ["Доцентрове прискорення забезпечує лише тертя.",
              "**m·v²/R = μ·m·g** → **v = √(μ·g·R)**; v²/R — нормальне прискорення (ФІ07).",
              f"v = √({f(mu)} · 9,81 · {R})"],
             f"v = √(μgR) ≈ **{f(v, 1)} м/с** ≈ {f(v * 3.6, 0)} км/год; маса скоротилась.")


def f11_coriolis(rng):
    m_t = pick(rng, 500, 1000, 2000)
    v_kmh = pick(rng, 54, 72, 90)
    phi = pick(rng, 45, 50, 60)
    F = 2 * m_t * 1000 * (2 * math.pi / 86400) * (v_kmh / 3.6) * math.sin(math.radians(phi))
    _scene(dict(kind="rails", v=f"{v_kmh} км/год", items=[dict(text="Fк = 2mωv·sin φ", stage=1), dict(text=f"Fк ≈ {f(F, 0)} Н", role="answer", stage=3)]))
    return P("Коріоліс і рейки", "ФІ11, ч. 7", ("курс ФІ11 (у OpenStax такої задачі немає)", ""), 2,
             f"Потяг масою **{m_t} т** їде на північ зі швидкістю **{v_kmh} км/год** на широті "
             f"**φ = {phi}°**. З якою силою він тисне вбік на праву рейку?",
             "F, Н", F, "Н",
             ["Це сила Коріоліса; ω — кутова швидкість Землі.",
              "**F = 2·m·ω·v·sin φ**, **ω = 2π ÷ 86 400 с ≈ 7,27·10⁻⁵ рад/с** (ФІ09).",
              f"F = 2 · {m_t * 1000} · 7,27·10⁻⁵ · {f(v_kmh / 3.6)} · sin {phi}°"],
             f"F = 2mωv·sin φ ≈ **{f(F, 0)} Н** — на праву рейку (північна півкуля).")


FI11 = [f11_sprinter, f11_push_up, f11_moon, f11_trampoline, f11_elevator, f11_crate_friction,
        f11_car, f11_braking, f11_truck_car, f11_crate_incline, f11_incline_time, f11_parcel,
        f11_table_hanging, f11_atwood, f11_scale_elevator, f11_pendulum_car, f11_curve,
        f11_coriolis]


# ======================================================================= ФІ12
def f12_momentum(rng):
    m = pick(rng, 1500, 2000, 2500)
    v = pick(rng, 10, 15, 20)
    _scene(dict(kind="body", label=f"{m} кг", items=[dict(dir=0, text=f"v = {v} м/с", role="motion", stage=0), dict(dir=90, text="p = m·v", role="aux", stage=2, len=1.0), dict(dir=-30, text=f"p = {f(m * v, 0)}", role="answer", stage=3, len=1.4)]))
    return P("Імпульс автомобіля", "ФІ12, ч. 2 · ФІ11, ч. 4", ("9.20", chap(9)), 1,
             f"Автомобіль масою **{m} кг** їде на схід зі швидкістю **{v} м/с**. Який його імпульс?",
             "p, кг·м/с", m * v, "кг·м/с",
             ["Імпульс — маса на швидкість, напрям — як у швидкості.",
              "**p = m·v** — у кг·м/с.", f"p = {m} · {v}"],
             f"p = m·v = **{f(m * v, 0)} кг·м/с**, на схід.")


def f12_rugby(rng):
    m = pick(rng, 90, 100, 110)
    v0 = pick(rng, 7.0, 8.0, 9.0)
    F = pick(rng, 1.2e4, 1.5e4, 1.76e4)
    t = pick(rng, 0.04, 0.05, 0.055)
    v = v0 - F * t / m
    _scene(dict(kind="body", label=f"{m} кг", items=[dict(dir=0, text=f"v₀ = {f(v0)}", role="motion", stage=0), dict(dir=180, text=f"F = {f(F, 0)} Н", stage=1), dict(dir=90, text=f"Δt = {f(t, 3)} с", role="aux", stage=2, len=0.9), dict(dir=-30, text=f"v ≈ {f(v)}", role="answer", stage=3, len=1.2)]))
    return P("Регбіст після зіткнення", "ФІ12, ч. 1 · ФІ11, ч. 4", ("9.28", chap(9)), 2,
             f"Регбіст масою **{m} кг** біжить зі швидкістю **{f(v0)} м/с** і зіштовхується з "
             f"суперником, який діє на нього силою **{f(F, 0)} Н** назад протягом **{f(t, 3)} с**. "
             "Яка швидкість регбіста після цього (зі знаком: «+» — вперед)?",
             "v, м/с", v, "м/с",
             ["Імпульс сили змінює імпульс тіла.",
              "**F·Δt = Δp = m·(v − v₀)**; сила назад — зі знаком мінус.",
              f"v = {f(v0)} − {f(F, 0)} · {f(t, 3)} ÷ {m}"],
             f"Δp = −F·Δt = −{f(F * t, 0)} кг·м/с; v = v₀ + Δp/m ≈ **{f(v)} м/с**.", tol=0.03)


def f12_hammer(rng):
    m = pick(rng, 0.4, 0.45, 0.5)
    v = pick(rng, 6.0, 7.0, 8.0)
    d = pick(rng, 0.008, 0.01, 0.012)
    t = 2 * d / v
    F = m * v / t
    _scene(dict(kind="body", ground="v", label=f"{f(m)} кг", items=[dict(dir=-90, text=f"v = {f(v)} м/с", role="motion", stage=0), dict(dir=90, text="F від цвяха", stage=1), dict(dir=0, text=f"d = {f(d * 100, 1)} см", role="aux", stage=2, len=0.9), dict(dir=150, text=f"F ≈ {f(F, 0)} Н", role="answer", stage=3, len=1.2)]))
    return P("Молоток забиває цвях", "ФІ12, ч. 1 · ФІ05", ("9.30", chap(9)), 2,
             f"Молоток масою **{f(m)} кг** зі швидкістю **{f(v)} м/с** вдаряє по цвяху й зупиняється, "
             f"забивши його на **{f(d * 100, 1)} см** (гальмування рівномірне). Яка середня сила удару?",
             "F, Н", F, "Н",
             ["Знайди час удару з кінематики, потім F = Δp/Δt.",
              "Рівносповільнено до нуля: **d = v·t/2** → **t = 2d/v**; **F = m·v ÷ t**.",
              f"t = 2 · {f(d)} ÷ {f(v)}; F = {f(m)} · {f(v)} ÷ t"],
             f"t = 2d/v ≈ {f(t, 4)} с; F = mv/t ≈ **{f(F, 0)} Н**.")


def f12_airbag(rng):
    m = pick(rng, 70, 75, 80)
    v = pick(rng, 15, 20, 25)
    d = pick(rng, 0.10, 0.15, 0.20)
    F = m * v ** 2 / (2 * d)
    _scene(dict(kind="body", label=f"{m} кг", items=[dict(dir=0, text=f"v = {v} м/с", role="motion", stage=0), dict(dir=180, text="F подушки", stage=1), dict(dir=-90, text=f"гальмівний шлях {f(d * 100, 0)} см", role="aux", stage=2, len=1.0), dict(dir=150, text=f"F ≈ {f(F, 0)} Н", role="answer", stage=3, len=1.3)]))
    return P("Подушка безпеки", "ФІ12, ч. 1", ("9.25", chap(9)), 2,
             f"Пасажир масою **{m} кг** на швидкості **{v} м/с** зупиняється подушкою безпеки, "
             f"яка стискається на **{f(d * 100, 0)} см**. Яка середня сила на пасажира?",
             "F, Н", F, "Н",
             ["Довший шлях гальмування — менша сила.",
              "**a = v² ÷ (2d)**, **F = m·a** (або через Δp і час t = 2d/v).",
              f"F = {m} · {v}² ÷ (2 · {f(d)})"],
             f"F = mv²/(2d) ≈ **{f(F, 0)} Н**. На жорсткій панелі (1 см) було б у {f(d / 0.01, 0)} разів більше.")


def f12_ice_throw(rng):
    M = pick(rng, 55, 65, 75)
    m = pick(rng, 0.5, 1.0, 2.0)
    v = pick(rng, 5.0, 6.7, 8.0)
    V = m * v / M
    _scene(dict(kind="before_after", before=[dict(x=0, label=f"{M}+{f(m)} кг", w=1.6)], after=[dict(x=-1.0, label=f"{M} кг", w=1.2, v=dict(len=-1.0, text="V = ?", stage=1)), dict(x=1.6, label=f"{f(m)} кг", shape="dot", v=dict(len=1.3, text=f"{f(v)} м/с")), dict(x=-2.8, label="", shape="dot", stage=3, v=dict(len=-0.6, text=f"V ≈ {f(V, 3)}", role="answer", stage=3))]))
    return P("Кидок на льоду", "ФІ12, ч. 2", ("9.50", chap(9)), 1,
             f"Людина масою **{M} кг** стоїть на гладкому льоду і кидає горизонтально м'яч масою "
             f"**{f(m)} кг** зі швидкістю **{f(v)} м/с**. З якою швидкістю вона відкотиться?",
             "V, м/с", V, "м/с",
             ["Спочатку все стояло: сумарний імпульс нуль.",
              "**0 = m·v − M·V** → **V = m·v ÷ M** — M — маса людини, V — її швидкість назад.",
              f"V = {f(m)} · {f(v)} ÷ {M}"],
             f"V = mv/M ≈ **{f(V, 3)} м/с** — назад.", tol=0.03)


def f12_coupling(rng):
    m1 = pick(rng, 1.2e5, 1.5e5, 1.8e5)
    v1 = pick(rng, 0.30, 0.40, 0.50)
    m2 = pick(rng, 0.8e5, 1.1e5, 1.4e5)
    v2 = pick(rng, 0.10, 0.12, 0.20)
    u = (m1 * v1 - m2 * v2) / (m1 + m2)
    _scene(dict(kind="before_after", before=[dict(x=-1.6, label=f"{f(m1, 0)}", w=1.6, v=dict(len=1.0, text=f"{f(v1)} →")), dict(x=1.6, label=f"{f(m2, 0)}", w=1.6, v=dict(len=-1.0, text=f"← {f(v2)}"))], after=[dict(x=0, label="разом", w=1.8, v=dict(len=1.0 if u > 0 else -1.0, text="u = ?", stage=1)), dict(x=-2.8 if u > 0 else 2.8, label="", shape="dot", stage=3, v=dict(len=0.6 if u > 0 else -0.6, text=f"u ≈ {f(u, 3)}", role="answer", stage=3))]))
    return P("Зчеплення вагонів назустріч", "ФІ12, ч. 5", ("9.35", chap(9)), 2,
             f"Вагон **{f(m1, 0)} кг** їде на схід зі швидкістю **{f(v1)} м/с** і зчіплюється з "
             f"вагоном **{f(m2, 0)} кг**, що їде на захід зі швидкістю **{f(v2)} м/с**. Яка "
             "швидкість зчеплених вагонів («+» — на схід)?",
             "u, м/с", u, "м/с",
             ["Непружний удар: далі рухаються разом, зберігається лише імпульс.",
              "**m₁v₁ − m₂v₂ = (m₁ + m₂)·u** — швидкість на захід зі знаком мінус.",
              f"u = ({f(m1, 0)} · {f(v1)} − {f(m2, 0)} · {f(v2)}) ÷ {f(m1 + m2, 0)}"],
             f"u ≈ **{f(u, 3)} м/с** ({'на схід' if u > 0 else 'на захід'}).", tol=0.03)


def f12_bullet_block(rng):
    m = pick(rng, 0.01, 0.02, 0.05)
    v = pick(rng, 300, 400, 500)
    M = pick(rng, 1.0, 1.5, 2.0)
    u = m * v / (m + M)
    _scene(dict(kind="before_after", before=[dict(x=-2.2, label=f"{f(m * 1000, 0)} г", shape="dot", v=dict(len=1.3, text=f"{v} м/с")), dict(x=1.2, label=f"{f(M)} кг", w=1.2)], after=[dict(x=0.4, label="разом", w=1.4, v=dict(len=1.2, text="u = ?", stage=1)), dict(x=-2.5, label="", shape="dot", stage=3, v=dict(len=0.9, text=f"u ≈ {f(u, 3)}", role="answer", stage=3))]))
    return P("Куля застрягає в бруску", "ФІ12, ч. 5", ("9.37", chap(9)), 1,
             f"Куля масою **{f(m * 1000, 0)} г** летить зі швидкістю **{v} м/с** і застрягає в "
             f"нерухомому бруску масою **{f(M)} кг** на гладкому столі. Яка швидкість бруска з кулею?",
             "u, м/с", u, "м/с",
             ["Непружний удар — лише імпульс.",
              "**m·v = (m + M)·u**; масу кулі переведи в кілограми.",
              f"u = {f(m)} · {v} ÷ ({f(m)} + {f(M)})"],
             f"u = mv/(m + M) ≈ **{f(u, 3)} м/с**.")


def f12_skater_pickup(rng):
    m1 = pick(rng, 45, 50, 55)
    v1 = pick(rng, 5.0, 5.5)
    m2 = round(m1 * 1.5)
    v2 = pick(rng, 6.0, 6.2, 6.5)
    u = (m1 * v1 + m2 * v2) / (m1 + m2)
    _scene(dict(kind="before_after", before=[dict(x=-1.8, label=f"{m2} кг", w=1.1, v=dict(len=1.3, text=f"{f(v2)}")), dict(x=1.4, label=f"{m1} кг", w=1.0, v=dict(len=1.1, text=f"{f(v1)}"))], after=[dict(x=0, label=f"{m1 + m2} кг", w=1.6, v=dict(len=1.2, text="u = ?", stage=1)), dict(x=-2.8, label="", shape="dot", stage=3, v=dict(len=0.8, text=f"u ≈ {f(u, 3)}", role="answer", stage=3))]))
    return P("Фігурист підхоплює партнерку", "ФІ12, ч. 5", ("9.41", chap(9)), 1,
             f"Партнерка **{m1} кг** ковзає зі швидкістю **{f(v1)} м/с**; партнер **{m2} кг** "
             f"наздоганяє її зі швидкістю **{f(v2)} м/с** і підхоплює. Яка їхня спільна швидкість?",
             "u, м/с", u, "м/с",
             ["Після підхоплення рухаються разом — непружна взаємодія.",
              "**m₁v₁ + m₂v₂ = (m₁ + m₂)·u**.",
              f"u = ({m1} · {f(v1)} + {m2} · {f(v2)}) ÷ {m1 + m2}"],
             f"u ≈ **{f(u, 3)} м/с** — між двома швидкостями, ближче до важчого.")


def f12_grain(rng):
    M = pick(rng, 2000, 3000, 4000)
    v0 = pick(rng, 4.0, 4.4, 5.0)
    vmin = pick(rng, 3.0, 3.5)
    mg = M * (v0 / vmin - 1)
    _scene(dict(kind="body", label=f"{M} кг", items=[dict(dir=0, text=f"{f(v0)} м/с", role="motion", stage=0), dict(dir=-90, text="зерно ↓", stage=1, len=0.01), dict(dir=90, text="зерно падає вертикально", role="aux", stage=1, len=1.1), dict(dir=-30, text=f"m ≈ {f(mg, 0)} кг", role="answer", stage=3, len=1.3)]))
    return P("Вагон під зерновим бункером", "ФІ12, ч. 2", ("9.42", chap(9)), 2,
             f"Порожній вагон масою **{M} кг** котиться без тертя зі швидкістю **{f(v0)} м/с** під "
             f"бункером, з якого вертикально сиплеться зерно. Швидкість не повинна впасти нижче "
             f"**{f(vmin)} м/с**. Яку найбільшу масу зерна можна завантажити?",
             "m зерна, кг", mg, "кг",
             ["Зерно падає вертикально — горизонтального імпульсу не додає.",
              "Горизонтально: **M·v₀ = (M + m)·v** → **m = M·(v₀/v − 1)**.",
              f"m = {M} · ({f(v0)} ÷ {f(vmin)} − 1)"],
             f"m = M(v₀/v − 1) ≈ **{f(mg, 0)} кг**.")


def f12_bumper(rng):
    m = pick(rng, 300, 400)
    v1 = pick(rng, 6.0, 6.5)       # задній
    v2 = pick(rng, 5.0, 5.6)       # передній
    # пружний удар рівних мас — обмін швидкостями
    _scene(dict(kind="before_after", before=[dict(x=-1.6, label=f"{m} кг", w=1.0, v=dict(len=1.3, text=f"{f(v1)}")), dict(x=1.2, label=f"{m} кг", w=1.0, v=dict(len=1.1, text=f"{f(v2)}"))], after=[dict(x=-1.6, label="задня", w=1.0, v=dict(len=1.1, text=f"{f(v2)}", role="answer", stage=3)), dict(x=1.2, label="передня", w=1.2, v=dict(len=1.3, text=f"{f(v1)}", stage=2))]))
    return P("Пружний удар однакових машинок", "ФІ12, ч. 4", ("9.47", chap(9)), 2,
             f"Дві однакові машинки атракціону по **{m} кг** рухаються в один бік: передня — "
             f"**{f(v2)} м/с**, задня — **{f(v1)} м/с**. Задня наздоганяє, удар пружний. Яка швидкість "
             "задньої машинки після удару?",
             "u задньої, м/с", v2, "м/с",
             ["Пружний удар: зберігаються імпульс і кінетична енергія.",
              "Для РІВНИХ мас розв'язок системи — **обмін швидкостями**: u₁ = v₂, u₂ = v₁ (ФІ12, ч. 4).",
              f"u₁ = v₂ = {f(v2)}"],
             f"Маси рівні → машинки обмінюються швидкостями: задня їде **{f(v2)} м/с**, передня — {f(v1)} м/с.")


def f12_firecracker(rng):
    m = pick(rng, 100, 150, 200)
    m1 = pick(rng, 60, 72, 90)
    if m1 >= m:
        m1 = m - 30
    v1 = pick(rng, 15, 20, 25)
    v2 = m1 * v1 / (m - m1)
    _scene(dict(kind="vectors", items=[dict(dir=180, text=f"{m1} г · {v1} м/с", stage=0), dict(dir=0, text="v₂ = ?", stage=1), dict(dir=0, text=f"v₂ ≈ {f(v2, 1)} м/с", role="answer", stage=3, len=2.3)], axes=("x", "")))
    return P("Петарда розривається у верхній точці", "ФІ12, ч. 2", ("9.46", chap(9)), 1,
             f"Петарда масою **{m} г** у верхній точці траєкторії (швидкість нуль) розривається на "
             f"дві частини. Частина **{m1} г** летить горизонтально ліворуч зі швидкістю "
             f"**{v1} м/с**. З якою швидкістю летить друга?",
             "v₂, м/с", v2, "м/с",
             ["У верхній точці петарда на мить зупинилась: імпульс до розриву — нуль.",
              "**0 = −m₁·v₁ + m₂·v₂**, m₂ = m − m₁; друга летить праворуч.",
              f"v₂ = {m1} · {v1} ÷ {m - m1}"],
             f"v₂ = m₁v₁/(m − m₁) ≈ **{f(v2, 1)} м/с** праворуч.")


def f12_intersection(rng):
    vA = pick(rng, 20, 25, 30)
    ang = pick(rng, 28, 35, 45)
    vB = vA / math.tan(math.radians(ang))
    _scene(dict(kind="vectors", items=[dict(dir=90, text=f"A: {vA} м/с", stage=0), dict(dir=0, text="B: ?", stage=0), dict(dir=ang, text=f"разом, {ang}°", stage=1, len=2.2), dict(dir=0, text=f"vB ≈ {f(vB, 1)}", role="answer", stage=3, len=2.4)], axes=("схід", "північ")))
    return P("Зіткнення на перехресті", "ФІ12, ч. 2, 5", ("9.62", chap(9)), 2,
             f"Два однакові автомобілі зіштовхуються на слизькому перехресті і зчіплюються. "
             f"Автомобіль A їхав на північ зі швидкістю **{vA} м/с**, B — на схід. Після зіткнення "
             f"уламки рухаються під кутом **{ang}°** на північ від сходу. Якою була швидкість B?",
             "v_B, м/с", vB, "м/с",
             ["Імпульс — вектор: окремо по осях схід і північ.",
              "Схід: **m·v_B = 2m·u·cos θ**; північ: **m·v_A = 2m·u·sin θ** → **tg θ = v_A / v_B**.",
              f"v_B = {vA} ÷ tg {ang}°"],
             f"tg θ = v_A/v_B → v_B = v_A/tg θ ≈ **{f(vB, 1)} м/с**.")


def f12_com_triangle(rng):
    m1 = pick(rng, 100, 150)
    m2 = pick(rng, 75, 50)
    m3 = pick(rng, 150, 200)
    a = pick(rng, 3, 4)
    b = 7 - a
    # m1 у (0,0), m2 у (a,0), m3 у (0,b)
    x = m2 * a / (m1 + m2 + m3)
    _scene(dict(kind="points", pts=[dict(x=0, y=0, label=f"{m1} г"), dict(x=a, y=0, label=f"{m2} г"), dict(x=0, y=b, label=f"{m3} г")], cm=(x, m3 * b / (m1 + m2 + m3))))
    return P("Центр мас трьох тіл", "ФІ12, ч. 3", ("9.63", chap(9)), 1,
             f"Три тіла лежать у вершинах прямокутного трикутника: **{m1} г** у початку координат, "
             f"**{m2} г** у точці (**{a} см**, 0), **{m3} г** у точці (0, **{b} см**). Яка координата x "
             "центру мас?",
             "x_цм, см", x, "см",
             ["Центр мас — середнє положення, зважене масами.",
              "**x_цм = Σ mᵢ·xᵢ ÷ Σ mᵢ**; у двох тіл x = 0.",
              f"x = {m2} · {a} ÷ ({m1} + {m2} + {m3})"],
             f"x_цм = {m2}·{a} ÷ {m1 + m2 + m3} ≈ **{f(x, 3)} см**; y_цм = {m3}·{b} ÷ {m1 + m2 + m3} ≈ "
             f"{f(m3 * b / (m1 + m2 + m3), 3)} см.")


def f12_rocket(rng):
    u = pick(rng, 1500, 2000, 2500)
    ratio = pick(rng, 1.5, 2.0, 3.0)
    dv = u * math.log(ratio)
    _scene(dict(kind="rocket", label=f"m₀ ÷ m = {f(ratio)}", u=f"u = {u} м/с", items=[dict(text="Δv = ?", stage=1), dict(text=f"Δv ≈ {f(dv, 0)} м/с", role="answer", stage=3)]))
    return P("Ракета у відкритому космосі", "ФІ12, ч. 6", ("9.79", chap(9)), 2,
             f"Ракета далеко від тяжіння спалює паливо, і її маса зменшується в **{f(ratio)} раза**. "
             f"Швидкість витікання газів відносно ракети **u = {u} м/с**. На скільки зросте швидкість ракети?",
             "Δv, м/с", dv, "м/с",
             ["Змінна маса — формула Ціолковського.",
              "**Δv = u·ln(m₀ ÷ m)** — m₀ — стартова маса, m — кінцева, ln — натуральний логарифм.",
              f"Δv = {u} · ln {f(ratio)}"],
             f"Δv = u·ln(m₀/m) ≈ {u} · {f(math.log(ratio), 3)} ≈ **{f(dv, 0)} м/с**.")


FI12 = [f12_momentum, f12_ice_throw, f12_bullet_block, f12_skater_pickup, f12_firecracker,
        f12_com_triangle, f12_rugby, f12_hammer, f12_airbag, f12_coupling, f12_grain,
        f12_bumper, f12_intersection, f12_rocket]


# ======================================================================= ФІ13
def f13_wrench(rng):
    M = pick(rng, 40, 50, 62, 70)
    r = pick(rng, 0.15, 0.20, 0.25)
    F = M / r
    _scene(dict(kind="lever", L=3.0, pivot=0.0, items=[dict(x=3.0, text="F = ?", stage=0), dict(x=3.0, text=f"F = {f(F, 1)} Н", role="answer", stage=3, dir="up")], dims=[(0, 3.0, f"h = {f(r * 100, 0)} см")]))
    return P("Затягнути болт ключем", "ФІ13, ч. 3", ("10.72", chap(10)), 1,
             f"Болт треба затягнути моментом **M = {M} Н·м** ключем довжиною **{f(r * 100, 0)} см**. "
             "Яку силу, перпендикулярну до ключа, треба прикласти до його кінця?",
             "F, Н", F, "Н",
             ["Момент сили — сила на плече.",
              "**M = F·h** — h — плече, відстань від осі до лінії сили (тут довжина ключа, у м).",
              f"F = {M} ÷ {f(r)}"],
             f"F = M/h = {M} ÷ {f(r)} = **{f(F, 1)} Н**.")


def f13_door(rng):
    F1 = pick(rng, 15.0, 17.5, 20.0)
    r1 = pick(rng, 0.6, 0.7, 0.8)
    r2 = pick(rng, 0.3, 0.45)
    F2 = F1 * r1 / r2
    _scene(dict(kind="lever", L=3.0, pivot=0.0, items=[dict(x=3.0 * r1 / 0.8, text=f"F₁ = {f(F1)} Н", stage=0), dict(x=3.0 * r2 / 0.8, text="F₂ = ?", dir="up", stage=0), dict(x=3.0 * r2 / 0.8, text=f"F₂ ≈ {f(F2, 1)} Н", dir="up", role="answer", stage=3)], dims=[(0, 3.0 * r1 / 0.8, f"{f(r1)} м"), (0, 3.0 * r2 / 0.8, f"{f(r2)} м")]))
    return P("Двоє тримають двері", "ФІ13, ч. 3, 5", ("12.29", chap(12)), 1,
             f"Одна дитина штовхає двері силою **{f(F1)} Н** на відстані **{f(r1)} м** від завіс, "
             f"друга — з іншого боку на відстані **{f(r2)} м**. Яку силу має прикласти друга, щоб двері "
             "не рухались? (сили перпендикулярні до дверей)",
             "F₂, Н", F2, "Н",
             ["Рівновага обертання: моменти рівні й протилежні.",
              "**F₁·h₁ = F₂·h₂** — ΣM = 0 відносно завіс.",
              f"F₂ = {f(F1)} · {f(r1)} ÷ {f(r2)}"],
             f"F₂ = F₁h₁/h₂ ≈ **{f(F2, 1)} Н** — більша, бо плече менше.")


def f13_points(rng):
    m = pick(rng, 0.2, 0.3, 0.5)
    rs = sorted(rng.sample([0.1, 0.2, 0.3, 0.4, 0.5], 3))
    I = m * sum(r * r for r in rs)
    _scene(dict(kind="points", rod=4.0, pts=[dict(x=r * 8, y=0, label=f"{f(m)} кг", r=f"{f(r)} м") for r in rs]))
    return P("Момент інерції трьох точок", "ФІ13, ч. 1", ("10.54", chap(10)), 1,
             f"Три кульки по **{f(m)} кг** закріплені на легкому стрижні на відстанях "
             f"**{', '.join(f(r) for r in rs)} м** від осі обертання. Який момент інерції системи?",
             "I, кг·м²", I, "кг·м²",
             ["Моменти інерції точок додаються.",
              "**I = Σ mᵢ·rᵢ²** — r — відстань до осі, у квадраті.",
              "I = " + " + ".join(f"{f(m)}·{f(r)}²" for r in rs)],
             f"I = {f(m)}·({' + '.join(f(r * r, 3) for r in rs)}) = **{f(I, 4)} кг·м²**.")


def f13_rod_axis(rng):
    m = pick(rng, 0.5, 1.0, 2.0)
    L = pick(rng, 0.6, 1.2, 1.8)
    k = pick(rng, 4, 6)
    d = L / 2 - L / k
    I = m * L ** 2 / 12 + m * d ** 2
    _scene(dict(kind="lever", L=6.0, pivot=6.0 / k, items=[dict(x=3.0, text="центр мас", role="aux", stage=1)], dims=[(6.0 / k, 3.0, f"d = {f(d, 3)} м"), (0, 6.0, f"L = {f(L)} м")]))
    return P("Стрижень: вісь не через центр", "ФІ13, ч. 2", ("10.65", chap(10)), 2,
             f"Однорідний стрижень масою **{f(m)} кг** і довжиною **{f(L)} м** обертається навколо "
             f"перпендикулярної осі на відстані **L/{k}** від одного кінця. Знайди момент інерції.",
             "I, кг·м²", I, "кг·м²",
             ["Вісь не через центр мас — теорема Штейнера.",
              "**I = I₀ + m·d²**, **I₀ = m·L²/12** (вісь через центр), **d = L/2 − L/k** — відстань між осями.",
              f"d = {f(L)}/2 − {f(L)}/{k} = {f(d, 3)} м; I = {f(m)}·{f(L)}²/12 + {f(m)}·{f(d, 3)}²"],
             f"I₀ = {f(m * L * L / 12, 4)}; m·d² = {f(m * d * d, 4)}; I = **{f(I, 4)} кг·м²**.")


def f13_flywheel_torque(rng):
    I = pick(rng, 4.0, 20.0, 50.0)
    w = pick(rng, 20.0, 100.0, 200.0)
    t = pick(rng, 5.0, 10.0)
    M = I * w / t
    _scene(dict(kind="disk", label=f"I = {f(I)} кг·м²", w=f"0 → {f(w)} рад/с за {f(t)} с", items=[dict(kind="M", text="M = ?", stage=1), dict(kind="M", text=f"M = {f(M, 1)} Н·м", role="answer", stage=3)]))
    return P("Момент для розгону маховика", "ФІ13, ч. 4", ("10.86", chap(10)), 1,
             f"Маховик із моментом інерції **I = {f(I)} кг·м²** з місця розганяється до "
             f"**ω = {f(w)} рад/с** за **{f(t)} с**. Який сталий момент сили діє?",
             "M, Н·м", M, "Н·м",
             ["Основний закон обертання.",
              "**M = I·ε**, **ε = ω ÷ t** — кутове прискорення, як a = v/t.",
              f"ε = {f(w)} ÷ {f(t)}; M = {f(I)} · ε"],
             f"ε = {f(w / t)} рад/с²; M = Iε = **{f(M, 1)} Н·м**.")


def f13_friction_stop(rng):
    I = pick(rng, 50.0, 100.0, 200.0)
    rpm = pick(rng, 300, 500, 600)
    t = pick(rng, 60, 120)
    w = rpm * 2 * math.pi / 60
    M = I * w / t
    _scene(dict(kind="disk", label=f"I = {f(I)} кг·м²", w=f"{rpm} об/хв → 0 за {t} с", items=[dict(kind="M", text="M тертя", stage=1), dict(kind="M", text=f"M ≈ {f(M, 1)} Н·м", role="answer", stage=3)]))
    return P("Тертя зупиняє маховик", "ФІ13, ч. 4 · ФІ09", ("10.89", chap(10)), 2,
             f"Маховик (**I = {f(I)} кг·м²**) обертається з частотою **{rpm} об/хв** і через "
             f"**{t} с** після вимкнення зупиняється. Який момент сил тертя?",
             "M, Н·м", M, "Н·м",
             ["Спершу частоту в рад/с, потім ε і M.",
              "**ω = 2π·n**, n — оберти за секунду (об/хв ÷ 60); **ε = ω/t**, **M = I·ε**.",
              f"ω = 2π · {rpm}/60; M = {f(I)} · ω ÷ {t}"],
             f"ω ≈ {f(w)} рад/с; ε ≈ {f(w / t, 3)} рад/с²; M = Iε ≈ **{f(M, 1)} Н·м**.")


def f13_grind_omega(rng):
    M = pick(rng, 30.0, 50.0, 80.0)
    I = pick(rng, 10.0, 20.0, 40.0)
    t = pick(rng, 10.0, 20.0)
    w = M * t / I
    _scene(dict(kind="disk", label=f"I = {f(I)} кг·м²", w="ω = ?", items=[dict(kind="M", text=f"M = {f(M)} Н·м, {f(t)} с", stage=0), dict(kind="M", text=f"ω = {f(w, 1)} рад/с", role="answer", stage=3)]))
    return P("Розкрутити шліфувальний круг", "ФІ13, ч. 4", ("10.88", chap(10)), 1,
             f"На круг (**I = {f(I)} кг·м²**), що стояв, протягом **{f(t)} с** діє момент "
             f"**{f(M)} Н·м**. Якої кутової швидкості він набуде?",
             "ω, рад/с", w, "рад/с",
             ["M = I·ε, потім рівноприскорене обертання.",
              "**ε = M ÷ I**, **ω = ε·t** (з місця).",
              f"ω = {f(M)} ÷ {f(I)} · {f(t)}"],
             f"ε = M/I = {f(M / I)} рад/с²; ω = εt = **{f(w, 1)} рад/с**.")


def f13_cart_pulley(rng):
    M = pick(rng, 3.0, 4.0)
    m = pick(rng, 1.0, 2.0)
    I = pick(rng, 0.2, 0.4)
    r = pick(rng, 0.2, 0.25)
    a = m * G / (M + m + I / r ** 2)
    _scene(dict(kind="pulley", mode="table", M=f"{f(M)} кг", m=f"{f(m)} кг", items=[dict(who="M", text="T₁", stage=1), dict(who="m", dir="up", text="T₂", stage=1), dict(who="m", dir="down", text="m·g", stage=2), dict(who="M", text=f"a ≈ {f(a, 3)}", role="answer", stage=3)]))
    return P("Візок, вантаж і блок з масою", "ФІ13, ч. 4 · ФІ11, ч. 4", ("10.94", chap(10)), 2,
             f"Візок **{f(M)} кг** на гладкому столі тягне вантаж **{f(m)} кг** через блок з моментом "
             f"інерції **I = {f(I)} кг·м²** і радіусом **{f(r)} м** (нитка не ковзає). Яке прискорення візка?",
             "a, м/с²", a, "м/с²",
             ["Три рівняння: візок, вантаж, блок.",
              "**M·a = T₁**, **m·a = m·g − T₂**, **(T₂ − T₁)·r = I·a/r** → **a = m·g ÷ (M + m + I/r²)**.",
              f"a = {f(m)} · 9,81 ÷ ({f(M)} + {f(m)} + {f(I)}/{f(r)}²)"],
             f"I/r² = {f(I / r ** 2)} кг — «маса» блока; a ≈ **{f(a, 3)} м/с²**.")


def f13_scaffold(rng):
    Lm = 6.0
    mb = pick(rng, 30, 40)
    mp = pick(rng, 70, 80)
    xp = 1.0
    xe = Lm - 1.5
    # T_L = 2 T_R; рівновага: T_L + T_R = (mb + mp + me) g; моменти відносно лівого краю:
    # T_R·L = mb g L/2 + mp g xp + me g xe
    # 3T_R = W → T_R = W/3 → (mb+mp+me)·L/3 = mb·L/2 + mp·xp + me·xe
    me = (mb * Lm / 2 + mp * xp - (mb + mp) * Lm / 3) / (Lm / 3 - xe)
    me = abs(me)
    _scene(dict(kind="lever", L=6.0, items=[dict(x=0.0, text="Tл = 2Tп", dir="up", stage=1), dict(x=6.0, text="Tп", dir="up", stage=1), dict(x=1.0, text=f"маляр {mp} кг", stage=0), dict(x=3.0, text=f"{mb} кг", stage=2), dict(x=4.5, text="m₀ = ?", stage=0)], dims=[(0, 1.0, "1 м"), (4.5, 6.0, "1,5 м")]))
    return P("Риштування на двох тросах", "ФІ13, ч. 5", ("12.35", chap(12)), 2,
             f"Однорідне риштування масою **{mb} кг** і довжиною **6 м** висить на двох тросах на "
             f"кінцях. Маляр **{mp} кг** стоїть за **1 м** від лівого краю, обладнання — за **1,5 м** "
             "від правого. Натяг лівого троса вдвічі більший за правий. Яка маса обладнання?",
             "m обладнання, кг", me, "кг",
             ["Дві умови рівноваги + співвідношення натягів.",
              "**ΣF = 0**: T_л + T_п = (m_р + m_м + m_о)·g, Tл = 2Tп; **ΣM = 0** відносно лівого краю: "
              "T_п·6 = m_р·g·3 + m_м·g·1 + m_о·g·4,5.",
              "Підстав T_п = (m_р + m_м + m_о)·g/3 у рівняння моментів і розв'яжи щодо m_о."],
             f"(m_р + m_м + m_о)·2 = 3m_р + m_м + 4,5m_о → m_о = (2m_р + 2m_м − 3m_р − m_м) ÷ 2,5 "
             f"≈ **{f(me, 1)} кг**.", tol=0.03)


def f13_suv(rng):
    L = pick(rng, 2.6, 3.0, 3.2)
    p = pick(rng, 0.55, 0.60, 0.65)
    x = (1 - p) * L
    _scene(dict(kind="lever", L=6.0, supports=[0.0, 6.0], items=[dict(x=0.0, text=f"перед: {f(p * 100, 0)} %", dir="up", stage=1), dict(x=6.0, text=f"зад: {f((1 - p) * 100, 0)} %", dir="up", stage=1), dict(x=6.0 * (1 - p), text="m·g", stage=2), dict(x=6.0 * (1 - p), text=f"x = {f(x)} м", role="answer", dir="up", stage=3)], dims=[(0, 6.0, f"{f(L)} м")]))
    return P("Де центр мас позашляховика", "ФІ13, ч. 5 · ФІ12, ч. 3", ("12.30", chap(12)), 1,
             f"Відстань між осями позашляховика **{f(L)} м**; на передні колеса припадає "
             f"**{f(p * 100, 0)} %** ваги. На якій відстані позаду передньої осі центр мас?",
             "x, м", x, "м",
             ["Рівновага: моменти реакцій відносно центру мас рівні.",
              "Моменти відносно передньої осі: **N_зад·L = m·g·x**, N_зад = (1 − p)·m·g → **x = (1 − p)·L**.",
              f"x = (1 − {f(p)}) · {f(L)}"],
             f"x = (1 − p)·L = **{f(x)} м** позаду передньої осі.")


def f13_mass_slides(rng):
    M = pick(rng, 2.0, 3.0)
    R = pick(rng, 0.5, 0.6)
    m = pick(rng, 0.05, 0.2, 0.3)
    n0 = pick(rng, 2.0, 3.0)
    I0 = M * R ** 2 / 2 + m * R ** 2
    I1 = M * R ** 2 / 2
    n1 = n0 * I0 / I1
    _scene(dict(kind="disk", label=f"{f(M)} кг, R = {f(R)} м", w=f"{f(n0)} об/с → ?", masses=[dict(x=1.6, y=0, label=f"{f(m)} кг", stage=0)], items=[dict(kind="v", x=1.3, y=-0.2, dx=-1.0, dy=0, text="до центру", role="aux", stage=1), dict(kind="R", text="R", stage=2)]))
    return P("Тягарець ковзає до центру диска", "ФІ13, ч. 6", ("11.52", chap(11)), 2,
             f"Диск **{f(M)} кг** радіусом **{f(R)} м** обертається з частотою **{f(n0)} об/с**; на "
             f"краю лежить тягарець **{f(m)} кг**, який потім зсувається в центр. Яка нова частота?",
             "n, об/с", n1, "об/с",
             ["Зовнішнього моменту немає — момент імпульсу зберігається.",
              "**I₀·ω₀ = I₁·ω₁**; диск **M·R²/2**, тягарець на краю **m·R²**, у центрі — 0.",
              f"n = {f(n0)} · ({f(M)}·{f(R)}²/2 + {f(m)}·{f(R)}²) ÷ ({f(M)}·{f(R)}²/2)"],
             f"I₀ = {f(I0, 4)}, I₁ = {f(I1, 4)}; n = n₀·I₀/I₁ ≈ **{f(n1, 3)} об/с**.")


def f13_child_grabs(rng):
    m = pick(rng, 20, 22, 30)
    M = pick(rng, 100, 120, 150)
    R = pick(rng, 1.5, 1.8, 2.0)
    n0 = pick(rng, 0.4, 0.5)
    n1 = n0 * (M / 2) / (M / 2 + m)
    _scene(dict(kind="disk", label=f"{M} кг, R = {f(R)} м", w=f"{f(n0)} об/с → ?", masses=[dict(x=1.6, y=0, label=f"{m} кг", stage=1)], items=[dict(kind="R", text="R", stage=2)]))
    return P("Дитина хапається за карусель", "ФІ13, ч. 6", ("11.62", chap(11)), 1,
             f"Карусель — суцільний диск **{M} кг** радіусом **{f(R)} м** — обертається з частотою "
             f"**{f(n0)} об/с**. Дитина **{m} кг** хапається за її край. Яка нова частота?",
             "n, об/с", n1, "об/с",
             ["Збереження моменту імпульсу.",
              "**I₀·n₀ = (I₀ + m·R²)·n**, **I₀ = M·R²/2**; R² скорочується.",
              f"n = {f(n0)} · ({M}/2) ÷ ({M}/2 + {m})"],
             f"n = n₀·(M/2)/(M/2 + m) ≈ **{f(n1, 3)} об/с**.")


def f13_boy_jumps(rng):
    m = pick(rng, 40, 50, 60)
    v = pick(rng, 3.0, 4.0)
    R = pick(rng, 1.5, 2.0)
    I = pick(rng, 200.0, 300.0)
    w = m * v * R / (I + m * R ** 2)
    _scene(dict(kind="disk", label=f"I = {f(I)} кг·м²", w="ω = ?", masses=[dict(x=1.75, y=-0.9, label=f"{m} кг", stage=0)], items=[dict(kind="v", x=1.75, y=-0.9, dx=0, dy=1.2, text=f"{f(v)} м/с", stage=0), dict(kind="R", text=f"R = {f(R)} м", stage=2)]))
    return P("Хлопець застрибує на карусель", "ФІ13, ч. 6 · ФІ12, ч. 5", ("11.61", chap(11)), 2,
             f"Хлопець **{m} кг** біжить зі швидкістю **{f(v)} м/с** по дотичній до краю нерухомої "
             f"каруселі (радіус **{f(R)} м**, I = **{f(I)} кг·м²**) і застрибує на неї. Яка кутова швидкість каруселі?",
             "ω, рад/с", w, "рад/с",
             ["Непружна взаємодія з віссю — зберігається момент імпульсу.",
              "**m·v·R = (I + m·R²)·ω** — m·v·R — момент імпульсу хлопця відносно осі.",
              f"ω = {m} · {f(v)} · {f(R)} ÷ ({f(I)} + {m} · {f(R)}²)"],
             f"ω ≈ **{f(w, 3)} рад/с**.")


def f13_skater(rng):
    I0 = pick(rng, 0.4, 0.5, 0.6)
    n0 = pick(rng, 5.0, 6.0)
    n1 = pick(rng, 1.25, 1.5, 2.0)
    I1 = I0 * n0 / n1
    _scene(dict(kind="disk", label=f"I₀ = {f(I0)} кг·м²", w=f"{f(n0)} → {f(n1)} об/с", masses=[dict(x=-0.5, y=0, label="руки", stage=0), dict(x=1.4, y=0, label="розвів", stage=1)]))
    return P("Фігурист розводить руки", "ФІ13, ч. 6", ("11.64", chap(11)), 1,
             f"Фігурист обертається з частотою **{f(n0)} об/с** з моментом інерції "
             f"**{f(I0)} кг·м²**. Яким має стати момент інерції, щоб частота впала до **{f(n1)} об/с**?",
             "I, кг·м²", I1, "кг·м²",
             ["Момент імпульсу зберігається.",
              "**I₀·n₀ = I·n** → **I = I₀·n₀ ÷ n**.",
              f"I = {f(I0)} · {f(n0)} ÷ {f(n1)}"],
             f"I = I₀n₀/n = **{f(I1)} кг·м²** — розвести руки й ногу.")


def f13_gyro(rng):
    m = pick(rng, 0.3, 0.5)
    R = pick(rng, 0.08, 0.10)
    r = pick(rng, 0.12, 0.15)
    n = pick(rng, 30.0, 40.0)
    w = 2 * math.pi * n
    I = m * R ** 2 / 2
    wp = m * G * r / (I * w)
    _scene(dict(kind="lever", L=3.0, supports=[0.0], disk_end=True, items=[dict(x=3.0, text="m·g", stage=1), dict(x=0.0, text="опора", dir="up", stage=0)], dims=[(0, 3.0, f"r = {f(r * 100, 0)} см")]))
    return P("Прецесія дзиґи", "ФІ13, ч. 7", ("11.75", chap(11)), 2,
             f"Диск **{f(m)} кг** радіусом **{f(R * 100, 0)} см** обертається з частотою **{f(n)} об/с**; "
             f"його центр мас — на **{f(r * 100, 0)} см** від точки опори, вісь горизонтальна. З якою "
             "кутовою швидкістю він прецесує?",
             "ω_p, рад/с", wp, "рад/с",
             ["Сила тяжіння дає момент, який повертає вісь, а не перекидає її.",
              "**ω_p = M ÷ L = m·g·r ÷ (I·ω)**, **I = m·R²/2**, **ω = 2π·n**.",
              f"ω_p = {f(m)} · 9,81 · {f(r)} ÷ ({f(I, 5)} · {f(w, 1)})"],
             f"M = mgr ≈ {f(m * G * r, 3)} Н·м; L = Iω ≈ {f(I * w, 4)} кг·м²/с; ω_p ≈ **{f(wp, 3)} рад/с**.",
             tol=0.03)


FI13 = [f13_wrench, f13_door, f13_points, f13_flywheel_torque, f13_grind_omega, f13_suv,
        f13_child_grabs, f13_skater, f13_rod_axis, f13_friction_stop, f13_cart_pulley,
        f13_scaffold, f13_mass_slides, f13_boy_jumps, f13_gyro]


def check(problem, text):
    """(ok, повідомлення) для введеної відповіді; кома й крапка — обидві годяться."""
    x = parse_number(text)
    if x is None:
        return None, "Введи число, наприклад 3,63 або 1,5·10⁵ (можна 1,5e5)"
    ans = problem["answer"]
    ok = abs(x - ans) <= problem["tol"] * max(abs(ans), 1e-9)
    return ok, ""


def parse_number(text):
    """«3,63», «3.63», «−2», «150 000», «1,5e5», «1,5·10⁵», «1,5*10^5» → float."""
    t = (text or "").strip().replace(" ", "").replace("\u00a0", "").replace(",", ".")
    t = t.replace("−", "-").replace("×", "*").replace("·", "*")
    t = t.translate(str.maketrans("⁻⁰¹²³⁴⁵⁶⁷⁸⁹", "-0123456789"))
    for sep in ("*10^", "*10"):
        if sep in t:
            mant, exp = t.split(sep, 1)
            t = f"{mant}e{exp}"
            break
    try:
        return float(t)
    except ValueError:
        return None
