"""Покрокові рисунки тренажерів ФІ14+ — SVG.

Додає до trainer_draw (його не змінюємо: на ньому стоять опубліковані
тренажери ФІ11–ФІ13) «вільну» сцену: задача сама перелічує лінії, стрілки
й підписи, кожен елемент — з кроку «st» (0 — умова, 1 — підказка 1,
2 — підказка 2, 3 — розв'язок). Решта типів сцен іде в trainer_draw.
Лише stdlib.
"""
import trainer_draw as D


def L(pts, col="ink", st=0, w=2, dash=False):
    return dict(t="line", pts=pts, col=col, st=st, w=w, dash=dash)


def A(x, y, dx, dy, col="force", st=0):
    return dict(t="arrow", x=x, y=y, dx=dx, dy=dy, col=col, st=st)


def Tx(x, y, s, col="ink", st=0, anchor="middle", size=14):
    return dict(t="text", x=x, y=y, s=s, col=col, st=st, anchor=anchor, size=size)


def R(cx, cy, w, h, col="accent", st=0):
    return dict(t="rect", cx=cx, cy=cy, w=w, h=h, col=col, st=st)


def Pg(pts, col="muted", st=0, fill=None):
    return dict(t="poly", pts=pts, col=col, st=st, fill=fill)


def Ci(x, y, r, col="accent", st=0, fill=None):
    return dict(t="circle", x=x, y=y, r=r, col=col, st=st, fill=fill)


def Dm(x0, x1, y, label, st=0):
    return dict(t="dim", x0=x0, x1=x1, y=y, label=label, st=st)


def free(lim, items):
    return dict(kind="free", lim=lim, items=items)


def _free(c, sc, st):
    for it in sc["items"]:
        if it["st"] > st:
            continue
        t = it["t"]
        if t == "line":
            c.line(it["pts"], it["col"], it["w"], it["dash"])
        elif t == "arrow":
            c.arrow(it["x"], it["y"], it["dx"], it["dy"], it["col"])
        elif t == "text":
            c.text(it["x"], it["y"], it["s"], it["col"], it["size"], it["anchor"])
        elif t == "rect":
            c.rect(it["cx"], it["cy"], it["w"], it["h"], it["col"])
        elif t == "poly":
            c.poly(it["pts"], it["col"], 2, it["fill"])
        elif t == "circle":
            c.circle(it["x"], it["y"], it["r"], it["col"], 2, it["fill"])
        elif t == "dim":
            c.dim(it["x0"], it["x1"], it["y"], it["label"])
    c.lim(*sc["lim"])


def svg(scene, stage, answer_text=None):
    """SVG-рядок рисунка на кроці stage (вільна сцена або будь-яка з trainer_draw)."""
    if scene.get("kind") != "free":
        return D.svg(scene, stage, answer_text)
    c = D.Canvas()
    _free(c, scene, stage)
    if stage >= 3 and answer_text:
        c.title = f"Відповідь: {answer_text}"
    return c.svg()
