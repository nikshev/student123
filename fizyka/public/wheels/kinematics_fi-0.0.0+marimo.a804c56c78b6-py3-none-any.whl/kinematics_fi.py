"""Чисті функції кінематики — спільні для ноутбуків ФІ.

Тримаються окремо від ноутбуків, щоб verify_*.py могли перевіряти ту саму
математику, не запускаючи marimo.

Модуль навмисно не тягне нічого, крім stdlib: `marimo export html-wasm`
пакує цей сусідній файл у wheel і ставить його через micropip у браузері
(перевірено на circuits_et04_06.py), і кожна зайва залежність тут — це
ще один шанс зірвати весь пакетний набір (урок lcapy/importlib з ЕТ).
"""
import math


def path_from_vt(times, speeds):
    """Площа під ламаною v(t) методом трапецій — пройдений шлях.

    Вузли з однаковим часом (вертикальний стрибок швидкості, «сходинка»)
    дозволені: така ділянка має Δt = 0 і площі не додає.

    Лише для `v ≥ 0` (ФІ05: уся площа над віссю). Щойно швидкість міняє
    знак, «площа під графіком» роздвоюється на переміщення (зі знаком)
    і пройдений шлях (без знака) — це тема ФІ10, і для неї є окрема пара
    `displacement_from_vt` / `distance_from_vt`. Від'ємна швидкість тут
    відхиляється, щоб функція з назвою «шлях» тихо не повернула
    переміщення.
    """
    if len(times) != len(speeds):
        raise ValueError("times і speeds мусять бути однакової довжини")
    if any(v < 0 for v in speeds):
        raise ValueError(
            "path_from_vt рахує лише v ≥ 0; для знакозмінної v бери "
            "displacement_from_vt (зі знаком) або distance_from_vt (шлях)"
        )
    return sum((speeds[i] + speeds[i + 1]) / 2 * (times[i + 1] - times[i])
               for i in range(len(times) - 1))


def displacement_from_vt(times, speeds):
    """Переміщення зі знаком: площа під ламаною v(t) методом трапецій,
    де ділянки під віссю часу входять з мінусом. Для ламаної це точна
    величина `∫v dt`, не наближення (ФІ10, крок `ploshcha_zi_znakom`)."""
    if len(times) != len(speeds):
        raise ValueError("times і speeds мусять бути однакової довжини")
    if len(times) < 2:
        raise ValueError("потрібно щонайменше два вузли")
    return sum((speeds[i] + speeds[i + 1]) / 2 * (times[i + 1] - times[i])
               for i in range(len(times) - 1))


def distance_from_vt(times, speeds):
    """Пройдений шлях: площа під ламаною `|v(t)|` — обидві частини, над
    і під віссю, беруться додатними. Якщо відрізок ламаної перетинає
    вісь часу, він ріжеться в точці перетину (там `v = 0`), бо трапеція
    від `+v_a` до `−v_b` без такого розрізу дала б знакову площу, а не
    модуль. Для ламаної результат точний. Ніколи не менший за
    `|displacement_from_vt|`; рівність — лише поки `v` не міняє знак."""
    if len(times) != len(speeds):
        raise ValueError("times і speeds мусять бути однакової довжини")
    if len(times) < 2:
        raise ValueError("потрібно щонайменше два вузли")
    total = 0.0
    for i in range(len(times) - 1):
        t0, t1 = times[i], times[i + 1]
        va, vb = speeds[i], speeds[i + 1]
        dt = t1 - t0
        if dt == 0:
            continue
        if va * vb < 0:
            # перетин осі: v лінійна на відрізку, нуль у частці |va|/(|va|+|vb|)
            t_cross = t0 + dt * abs(va) / (abs(va) + abs(vb))
            total += abs(va) / 2 * (t_cross - t0)
            total += abs(vb) / 2 * (t1 - t_cross)
        else:
            total += (abs(va) + abs(vb)) / 2 * dt
    return total


def normal_acceleration(v, r):
    """Нормальне (доцентрове) прискорення `a_n = v²/r`."""
    if r <= 0:
        raise ValueError("радіус кривизни мусить бути додатним")
    return v * v / r


def omega_from_rpm(rpm):
    """об/хв -> рад/с. Втрата 2π тут — найтиповіша помилка предмета."""
    return 2 * math.pi * rpm / 60


def period_from_omega(omega):
    """Період обертання `T = 2π/ω`."""
    if omega <= 0:
        raise ValueError("кутова швидкість мусить бути додатною")
    return 2 * math.pi / omega


def linear_speed(omega, r):
    """Лінійна швидкість точки на радіусі `r`: `v = ω·r`."""
    return omega * r


def tangential_acceleration(epsilon, r):
    """Тангенціальне прискорення точки на радіусі `r`: `a_τ = ε·r` —
    той самий рядок зведеної таблиці ФІ10, що й `v = ω·r`, тільки для
    кутового прискорення `ε`. Нормальне `a_n = ω²·r` окремої функції не
    потребує: це `normal_acceleration(linear_speed(ω, r), r)`."""
    return epsilon * r


def frequency_from_period(period):
    """Частота через період: `ν = 1/T`."""
    if period <= 0:
        raise ValueError("період мусить бути додатним")
    return 1 / period


def rpm_from_frequency(nu):
    """Обороти за хвилину через частоту: `n = 60·ν` — зворотний крок до
    `ν = n/60`. Разом з `omega_from_rpm` і `period_from_omega` замикає
    ланцюжок `n → ω → T → ν → n`, яким ФІ09 показує, що всі чотири
    подання одного обертання узгоджені одне з одним."""
    if nu < 0:
        raise ValueError("частота не буває від'ємною")
    return 60 * nu


def path_length(points):
    """Δs: сума довжин відрізків ламаної через задані точки (2D), у
    порядку проходження. Точки — послідовність пар `(x, y)`."""
    if len(points) < 2:
        raise ValueError("потрібно щонайменше дві точки")
    return sum(
        math.hypot(points[i + 1][0] - points[i][0],
                   points[i + 1][1] - points[i][1])
        for i in range(len(points) - 1)
    )


def displacement(points):
    """|Δr|: модуль переміщення — відстань по прямій між першою й
    останньою точкою, незалежно від того, що між ними."""
    if len(points) < 2:
        raise ValueError("потрібно щонайменше дві точки")
    x0, y0 = points[0]
    x1, y1 = points[-1]
    return math.hypot(x1 - x0, y1 - y0)


def total_acceleration(a_tau, a_n):
    """Модуль повного прискорення за правилом паралелограма:
    `|a| = √(a_τ² + a_n²)`, бо складові взаємно перпендикулярні
    (`a_τ` уздовж дотичної, `a_n` — до центра кривизни).

    `a_τ` може бути від'ємним (гальмування), `a_n = v²/R` — ніколи."""
    if a_n < 0:
        raise ValueError("нормальне прискорення не буває від'ємним")
    return math.sqrt(a_tau * a_tau + a_n * a_n)


def uniform_accel_x(x0, v0, a, t):
    """Координата при сталому прискоренні: `x(t) = x₀ + v₀·t + a·t²/2`.
    `a = 0` дає похилу пряму, `a ≠ 0` — параболу, вітки якої дивляться
    вгору при `a > 0` і вниз при `a < 0` (ФІ10). Працює і з масивами
    numpy у ролі `t`."""
    return x0 + v0 * t + a * t * t / 2


def uniform_accel_v(v0, a, t):
    """Швидкість при сталому прискоренні: `v(t) = v₀ + a·t` — похила
    пряма; це `dx/dt` для `uniform_accel_x`. Працює і з масивами numpy."""
    return v0 + a * t


def turning_time(v0, a):
    """Момент розвороту: `v(t*) = 0`, тобто `t* = −v₀/a`. Саме тут
    `v(t)` перетинає вісь часу, а `x(t)` має вершину параболи. При
    `a = 0` швидкість стала й розвороту не буває — ValueError. Повернене
    `t*` може бути від'ємним: тоді розворот був «до старту», тобто на
    відрізку `t ≥ 0` тіло напряму не міняє."""
    if a == 0:
        raise ValueError("при a = 0 швидкість стала, точки розвороту немає")
    return -v0 / a
