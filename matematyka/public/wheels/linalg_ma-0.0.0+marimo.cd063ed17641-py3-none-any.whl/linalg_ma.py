"""Чисті функції лінійної алгебри — спільні для ноутбуків МА.

Тримаються окремо від ноутбуків, щоб verify_*.py могли перевіряти ту саму
математику, не запускаючи marimo.

Модуль навмисно не тягне нічого, крім stdlib (`fractions.Fraction`):
`marimo export html-wasm` пакує цей сусідній файл у wheel і ставить його
через micropip у браузері, і кожна зайва залежність тут — це ще один шанс
зірвати весь пакетний набір (урок lcapy/importlib з ЕТ). `sympy` потрібен
лише верифікатору поряд, сюди не імпортується.

Усі функції беруть і повертають `list[list[Fraction | int]]` — плоскі
списки списків, без класу «матриця». Індекси мінору й алгебраїчного
доповнення — з **одиниці**, як у нотатках курсу, а не з нуля, як у Python.
"""
from fractions import Fraction


def _as_fraction(x):
    """Приводить елемент матриці (int або Fraction) до Fraction."""
    return x if isinstance(x, Fraction) else Fraction(x)


def is_conformable(A, B):
    """True, якщо кількість стовпців A дорівнює кількості рядків B —
    тобто добуток A·B визначений."""
    return len(A[0]) == len(B)


def matmul(A, B):
    """Добуток матриць A·B. Некомутативний: matmul(A, B) і matmul(B, A)
    можуть мати різну форму або не існувати взагалі."""
    if not is_conformable(A, B):
        raise ValueError(
            f"добуток не визначений: A має {len(A[0])} стовпців, "
            f"B має {len(B)} рядків"
        )
    n, m, p = len(A), len(A[0]), len(B[0])
    return [
        [sum(A[i][k] * B[k][j] for k in range(m)) for j in range(p)]
        for i in range(n)
    ]


def transpose(A):
    """Транспонована матриця Aᵀ: рядки стають стовпцями."""
    return [list(row) for row in zip(*A)]


def minor(A, i, j):
    """Мінор M_ij (мінор ЕЛЕМЕНТА): матриця без рядка i та стовпця j —
    та величина, що входить у означення алгебраїчного доповнення A_ij.

    Нумерація рядків і стовпців — з одиниці (як A₁₁, A₁₂ у нотатках),
    не з нуля.

    ⚠️ Не плутати з головним (обвідним) мінором порядку k з методу
    обвідних мінорів (означення рангу) — це геть інша величина з тим
    самим словом "мінор": головний мінор порядку k — верхній лівий кут
    матриці k×k, а не «матриця без рядка i і стовпця j». Наприклад для
    `C` з Лк2 Пр6 `minor(C, 2, 2)` (без рядка 2 і стовпця 2) і головний
    мінор M_II другого порядку (рядки 1–2, стовпці 1–2) — дві різні
    матриці з різними визначниками; див. примітку в
    `_reference/constants-matematyka.md`."""
    return [
        [A[r][c] for c in range(len(A[0])) if c != j - 1]
        for r in range(len(A)) if r != i - 1
    ]


def det(A):
    """Визначник рекурсивно, розкладом за першим рядком.

    Базові випадки 1×1 і 2×2 рахуються прямо (2×2 — щоб не заглиблюватись
    у мінори 1×1 зайвим рівнем рекурсії), інакше — сума `a_1j · A_1j` по
    першому рядку через `cofactor`."""
    n = len(A)
    if n == 1:
        return _as_fraction(A[0][0])
    if n == 2:
        a, b = _as_fraction(A[0][0]), _as_fraction(A[0][1])
        c, d = _as_fraction(A[1][0]), _as_fraction(A[1][1])
        return a * d - b * c
    return sum(
        (_as_fraction(A[0][j - 1]) * cofactor(A, 1, j) for j in range(1, n + 1)),
        start=Fraction(0),
    )


def cofactor(A, i, j):
    """Алгебраїчне доповнення A_ij = (−1)^(i+j) · det(M_ij).

    Знак — саме тут пастка предмета: загублений `(-1) ** (i + j)` не
    ламає нічого видимого (мінор лишається числом, det — числом,
    обернена — матрицею правильної форми), його ловить лише перевірка
    A·A⁻¹ = E у verify_linalg_ma.py."""
    return (-1) ** (i + j) * det(minor(A, i, j))


def adjugate(A):
    """Приєднана (союзна) матриця: транспонована матриця алгебраїчних
    доповнень — adj(A)[i][j] = A_ji (cofactor(A, j, i))."""
    n = len(A)
    cof = [[cofactor(A, i, j) for j in range(1, n + 1)] for i in range(1, n + 1)]
    return transpose(cof)


def inverse_via_adj(A):
    """Обернена матриця A⁻¹ = adj(A) / det(A) через алгебраїчні
    доповнення. Кидає ValueError, якщо det(A) == 0 (матриця вироджена)."""
    d = det(A)
    if d == 0:
        raise ValueError("матриця вироджена (det = 0): оберненої не існує")
    adj = adjugate(A)
    return [[x / d for x in row] for row in adj]


def to_triangular(A):
    """Зведення до трикутного вигляду методом Гаусса (елементарні
    перетворення рядків).

    Повертає (матриця, протокол кроків). Кожен крок протоколу —
    **структурований** словник, не готовий текст, щоб його можна було
    відтворити (програти по вихідній матриці й дістати той самий
    результат) — саме так це і перевіряє verify_linalg_ma.py, незалежною
    функцією-програвачем. Дві форми кроку:

    - `{"op": "combine", "row": i, "pivot_row": p, "factor": k}` —
      рядок i замінюється на `рядок i − k · рядок p` (заняулення
      елемента під ведучим);
    - `{"op": "swap", "row_a": i, "row_b": j}` — рядки i та j міняються
      місцями (ведучий елемент у поточному стовпці був нуль, а нижче
      знайшовся ненульовий).

    Усі індекси рядків — з одиниці. Людський текст для показу в
    ноутбуці ("рядок 3 − 2 × рядок 1") збирає окрема функція
    `format_step`, яка в обчисленні участі не бере.

    Стовпець, де ведучого елемента немає в жодному з рядків, що
    лишились, просто пропускається — це і є механізм, який фіксує ранг
    для матриць з лінійно залежними рядками."""
    M = [[_as_fraction(x) for x in row] for row in A]
    n_rows, n_cols = len(M), len(M[0])
    steps = []
    pivot_row = 0
    for col in range(n_cols):
        if pivot_row >= n_rows:
            break
        if M[pivot_row][col] == 0:
            swap_with = next(
                (r for r in range(pivot_row + 1, n_rows) if M[r][col] != 0),
                None,
            )
            if swap_with is None:
                continue
            M[pivot_row], M[swap_with] = M[swap_with], M[pivot_row]
            steps.append({
                "op": "swap",
                "row_a": pivot_row + 1,
                "row_b": swap_with + 1,
            })
        pivot = M[pivot_row][col]
        for r in range(pivot_row + 1, n_rows):
            if M[r][col] == 0:
                continue
            factor = M[r][col] / pivot
            M[r] = [M[r][c] - factor * M[pivot_row][c] for c in range(n_cols)]
            steps.append({
                "op": "combine",
                "row": r + 1,
                "pivot_row": pivot_row + 1,
                "factor": factor,
            })
        pivot_row += 1
    return M, steps


def format_step(step):
    """Людський опис одного кроку протоколу `to_triangular` для показу в
    ноутбуці — наприклад "рядок 3 − 2 × рядок 1" або "рядок 1 ↔ рядок 2".

    При від'ємному `factor` крок друкується як додавання
    ("рядок 3 + 3 × рядок 2"), а не як "рядок 3 − -3 × рядок 2"
    (подвійний знак нечитабельний). Ця функція лише форматує — сама
    структура кроку (`to_triangular`) від неї не залежить."""
    if step["op"] == "swap":
        return f"рядок {step['row_a']} ↔ рядок {step['row_b']}"
    factor = step["factor"]
    if factor >= 0:
        return f"рядок {step['row']} − {factor} × рядок {step['pivot_row']}"
    return f"рядок {step['row']} + {-factor} × рядок {step['pivot_row']}"


def rank_by_elementary(A):
    """Ранг матриці: кількість ненульових рядків після зведення до
    трикутного вигляду елементарними перетвореннями (`to_triangular`)."""
    tri, _ = to_triangular(A)
    return sum(1 for row in tri if any(x != 0 for x in row))
